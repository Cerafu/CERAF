class TranspositionTable:
    EXACT = 0
    ALPHA = 1  
    BETA = 2   

    # Any score at or beyond this magnitude is treated as a "mate score" and
    # must be re-based when it crosses a ply boundary (see _score_to_tt /
    # _score_from_tt below). Mate scores are search-local (they encode
    # "distance to mate from the root of THIS search call"); if they are
    # stored in the TT as-is, a later probe of the same position at a
    # different ply will read back a mate distance that is wrong for the
    # new ply, which can make the engine misjudge or miss forced mates.
    #
    # NOTE: this only works if the search passes `ply` to probe() and store().
    # (Before this upgrade search.py never did, so the re-basing was dead code.)
    MATE_THRESHOLD = 90000

    def __init__(self, size_mb: int = 64):
        self.size_mb = size_mb
        self._allocate(size_mb)
        self.current_age = 0

    def _allocate(self, size_mb: int):
        # Calculate capacity. In 64-bit Python/PyPy, a 6-item tuple + references is approx ~96 bytes.
        bytes_available = max(1, int(size_mb)) * 1024 * 1024
        target_entries = bytes_available // 96
        
        self.buckets = 1
        while self.buckets * 4 <= target_entries:
            self.buckets *= 2
            
        self.mask = self.buckets - 1
        self.capacity = self.buckets * 2
        
        # We pack entries as tuples to leverage Python's GIL for atomic, lock-free concurrency.
        # Tuple format: (zobrist_key, depth, score, flag, best_move, age)
        self.entries = [None] * self.capacity

    def resize(self, size_mb: int):
        """[UPGRADE] Change the table size (UCI 'Hash' option). Clears the table."""
        self.size_mb = size_mb
        self._allocate(size_mb)

    def clear(self):
        """[UPGRADE] Forget everything (used on ucinewgame / 'Clear Hash')."""
        self.entries = [None] * self.capacity
        self.current_age = 0

    def new_search(self):
        self.current_age += 1

    def hashfull(self) -> int:
        """[UPGRADE] Permill of slots filled with entries from the current search
        (UCI 'hashfull'), estimated from a fixed-size sample."""
        sample = min(1000, self.capacity)
        if sample == 0:
            return 0
        step = max(1, self.capacity // sample)
        used = 0
        counted = 0
        age = self.current_age
        entries = self.entries
        for i in range(0, self.capacity, step):
            counted += 1
            e = entries[i]
            if e is not None and e[5] == age:
                used += 1
            if counted >= sample:
                break
        return (used * 1000) // max(1, counted)

    @classmethod
    def _score_to_tt(cls, score: int, ply: int) -> int:
        """Re-base a mate score from 'distance to mate from root' to
        'distance to mate from this node' so it is safe to store keyed
        only by position (independent of how deep in the tree we are)."""
        if score >= cls.MATE_THRESHOLD:
            return score + ply
        if score <= -cls.MATE_THRESHOLD:
            return score - ply
        return score

    @classmethod
    def _score_from_tt(cls, score: int, ply: int) -> int:
        """Inverse of _score_to_tt: re-base a stored mate score back to
        'distance to mate from the root of the current search'."""
        if score >= cls.MATE_THRESHOLD:
            return score - ply
        if score <= -cls.MATE_THRESHOLD:
            return score + ply
        return score

    def get_move(self, zobrist_key: int):
        """[UPGRADE] Return only the stored best move for a position (or None).
        Used for PV reconstruction and for choosing a ponder move."""
        idx0 = (zobrist_key & self.mask) << 1
        entry = self.entries[idx0]
        if entry is not None and entry[0] == zobrist_key:
            return entry[4]
        entry = self.entries[idx0 + 1]
        if entry is not None and entry[0] == zobrist_key:
            return entry[4]
        return None

    def get_entry(self, zobrist_key: int):
        """[UPGRADE] Raw entry (key, depth, score, flag, move, age) or None."""
        idx0 = (zobrist_key & self.mask) << 1
        entry = self.entries[idx0]
        if entry is not None and entry[0] == zobrist_key:
            return entry
        entry = self.entries[idx0 + 1]
        if entry is not None and entry[0] == zobrist_key:
            return entry
        return None

    def probe(self, zobrist_key: int, depth: int, alpha: int, beta: int, ply: int = 0):
        idx0 = (zobrist_key & self.mask) << 1
        idx1 = idx0 + 1

        entry = self.entries[idx0]
        if entry is not None and entry[0] == zobrist_key:
            best_move = entry[4]
            if entry[1] >= depth:
                flag = entry[3]
                score = self._score_from_tt(entry[2], ply)
                if flag == self.EXACT:
                    return score, best_move
                elif flag == self.ALPHA and score <= alpha:
                    return alpha, best_move
                elif flag == self.BETA and score >= beta:
                    return beta, best_move
            return None, best_move

        entry = self.entries[idx1]
        if entry is not None and entry[0] == zobrist_key:
            best_move = entry[4]
            if entry[1] >= depth:
                flag = entry[3]
                score = self._score_from_tt(entry[2], ply)
                if flag == self.EXACT:
                    return score, best_move
                elif flag == self.ALPHA and score <= alpha:
                    return alpha, best_move
                elif flag == self.BETA and score >= beta:
                    return beta, best_move
            return None, best_move
                
        return None, None

    def store(self, zobrist_key: int, depth: int, score: int, flag: int, best_move, ply: int = 0):
        stored_score = self._score_to_tt(score, ply)
        idx0 = (zobrist_key & self.mask) << 1
        idx1 = idx0 + 1
        age = self.current_age
        entries = self.entries

        entry0 = entries[idx0]
        entry1 = entries[idx1]

        # [UPGRADE] Same position already present: update it in place instead of
        # creating a duplicate in the other slot, and never throw away a known
        # best move just because this store (e.g. a fail-low) has none.
        if entry0 is not None and entry0[0] == zobrist_key:
            if best_move is None:
                best_move = entry0[4]
            if depth >= entry0[1] or entry0[5] != age:
                entries[idx0] = (zobrist_key, depth, stored_score, flag, best_move, age)
            return
        if entry1 is not None and entry1[0] == zobrist_key:
            if best_move is None:
                best_move = entry1[4]
            if depth >= entry1[1] or entry1[5] != age:
                entries[idx1] = (zobrist_key, depth, stored_score, flag, best_move, age)
            return

        new_entry = (zobrist_key, depth, stored_score, flag, best_move, age)

        # Depth-preferred slot: take it if empty, stale, or the new entry is at least as deep.
        if entry0 is None or entry0[5] < age or depth >= entry0[1]:
            # [UPGRADE] Demote the displaced (still useful) entry into the
            # always-replace slot instead of silently discarding it.
            if entry0 is not None and entry0[5] == age:
                if entry1 is None or entry1[5] < age or entry0[1] >= entry1[1]:
                    entries[idx1] = entry0
            entries[idx0] = new_entry
            return

        # Otherwise use the always-replace slot.
        entries[idx1] = new_entry
