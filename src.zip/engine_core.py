import os
import re
import sys
import threading
import time
import chess
import chess.syzygy
import logging
import multiprocessing
from src.search import Search
from src.learning import tracker
from src.opening_book import get_book_move

TABLEBASES = None
SEARCH_ID = 0  
PONDER_ENABLED = True
MOVE_OVERHEAD_MS = 30       # [UPGRADE] safety margin for GUI/pipe/Python latency (UCI "Move Overhead")
SOFT_LIMIT_FRACTION = 0.6   # [UPGRADE] don't start a new iteration after this share of the budget

# [UPGRADE] CERAF's search runs in Python threads, and both CPython and PyPy have
# a global interpreter lock: N search threads share ONE core and each repeats
# the same work, so a default of cpu_count() slows the main thread down roughly
# N-fold (measured, see test report). Default to 1; the Threads option still works.
DEFAULT_THREADS = 1
try:
    MAX_CPU_THREADS = max(1, multiprocessing.cpu_count())
except Exception:
    MAX_CPU_THREADS = 1

def parse_go_args(tokens):
    params = {}
    i = 0
    while i < len(tokens):
        key = tokens[i]
        if key in ["wtime", "btime", "winc", "binc", "movestogo", "movetime", "depth", "nodes"]:
            if i + 1 < len(tokens):
                try:
                    params[key] = int(tokens[i+1])
                except ValueError:
                    pass
                i += 2
            else:
                break
        elif key in ["infinite", "mate"]:
            params[key] = True
            i += 1
        else:
            i += 1
    return params

def calculate_time_limit(board, params):
    time_limit = 999999.0  
    depth_limit = 100
    node_limit = None
    overhead = MOVE_OVERHEAD_MS / 1000.0

    if "infinite" in params:
        return time_limit, depth_limit, node_limit

    if "depth" in params:
        depth_limit = params["depth"]
    
    if "nodes" in params:
        node_limit = params["nodes"]

    if "movetime" in params:
        return max(0.001, params["movetime"] / 1000.0 - overhead), depth_limit, node_limit

    is_white = board.turn == chess.WHITE
    remaining_ms = params.get("wtime") if is_white else params.get("btime")
    inc_ms = params.get("winc", 0) if is_white else params.get("binc", 0)
    movestogo = params.get("movestogo")

    if remaining_ms is not None:
        remaining_sec = remaining_ms / 1000.0
        inc_sec = inc_ms / 1000.0

        if movestogo and movestogo > 0:
            base = remaining_sec / movestogo
        else:
            phase = min(24, chess.popcount(board.occupied))
            factor = 28.0 if phase > 12 else 40.0  
            base = remaining_sec / factor

        allocated = base + (inc_sec * 0.75) 
        allocated = min(allocated, remaining_sec * 0.22)  
        allocated = max(0.04, allocated) 

        if allocated >= remaining_sec:
            allocated = max(0.001, remaining_sec - 0.1)

        # [UPGRADE] never plan to use the last `overhead` seconds of the allotment
        allocated = max(0.001, allocated - overhead)
            
        time_limit = allocated
    elif "depth" not in params and "nodes" not in params:
        time_limit = 1.0

    return time_limit, depth_limit, node_limit

def calculate_soft_limit(params, time_limit):
    """[UPGRADE] Soft limit (stop deepening) only for real clock-managed moves.
    'movetime', 'depth', 'nodes' and 'infinite' keep their exact semantics."""
    if "infinite" in params or "movetime" in params:
        return None
    if "wtime" in params or "btime" in params:
        return time_limit * SOFT_LIMIT_FRACTION
    return None

def _safe_tracker(fn, *args):
    """[UPGRADE] Learning/PGN bookkeeping must never be able to break the UCI
    loop. Previously an exception while saving the game at 'quit' was swallowed
    by the generic handler, the 'break' was skipped and the engine kept running."""
    try:
        return fn(*args)
    except Exception as e:
        logging.error(f"Tracker error in {getattr(fn, '__name__', fn)}: {e}")
        return None

_SETOPTION_RE = re.compile(r"^setoption\s+name\s+(.*?)(?:\s+value\s+(.*))?\s*$", re.IGNORECASE)

def _load_tablebases(path_value):
    """Open one or more Syzygy directories (separated by os.pathsep)."""
    dirs = [p for p in path_value.split(os.pathsep) if p.strip()]
    if not dirs:
        raise ValueError("empty Syzygy path")
    tb = chess.syzygy.open_tablebase(dirs[0])
    for extra in dirs[1:]:
        tb.add_directory(extra)
    return tb

def uci_loop():
    global TABLEBASES
    global SEARCH_ID
    global PONDER_ENABLED
    global MOVE_OVERHEAD_MS
    
    board = chess.Board()
    search = Search()
    search.threads = DEFAULT_THREADS
    search_thread = None
    logging.info("UCI Loop Started")

    def stop_search_and_join(bump_id=False):
        global SEARCH_ID
        search.abort = True
        search.timeout = True
        if bump_id:
            SEARCH_ID += 1
        if search_thread and search_thread.is_alive():
            search_thread.join()

    while True:
        try:
            try:
                raw_line = sys.stdin.readline()
            except (ValueError, OSError):
                raw_line = ""

            # [UPGRADE] readline() returns '' ONLY at EOF (a blank line is '\n').
            # The old `if not line: continue` spun at 100% CPU forever whenever
            # the GUI closed the pipe or died without sending 'quit'.
            if raw_line == "":
                logging.info("stdin closed; shutting down.")
                stop_search_and_join(bump_id=True)
                _safe_tracker(tracker.save_current_game)
                break

            line = raw_line.strip()
            if not line:
                continue
            
            tokens = line.split()
            command = tokens[0]

            if command == "uci":
                print("id name CERAF Learning Ultra v2.0 SMP", flush=True)
                print("id author Cerafin C F", flush=True)
                print(f"option name Threads type spin default {DEFAULT_THREADS} min 1 max 128", flush=True)
                print("option name Hash type spin default 64 min 1 max 1024", flush=True)
                print("option name Clear Hash type button", flush=True)
                print(f"option name Move Overhead type spin default {MOVE_OVERHEAD_MS} min 0 max 5000", flush=True)
                print("option name SyzygyPath type string default <empty>", flush=True)
                print("option name SyzygyProbeDepth type spin default 1 min 1 max 100", flush=True)
                print("option name SyzygyProbeLimit type spin default 5 min 0 max 6", flush=True)
                print("option name Ponder type check default true", flush=True)
                print("option name UseLearnedWeights type check default false", flush=True)
                print("uciok", flush=True)
                
            elif command == "isready":
                print("readyok", flush=True)
                
            elif command == "setoption":
                m = _SETOPTION_RE.match(line)
                if m:
                    opt_name = m.group(1).strip().lower()
                    raw_val = (m.group(2) or "").strip()
                    opt_val = raw_val.lower()   # only for case-insensitive values; paths use raw_val
                    if opt_name == "threads":
                        try:
                            search.threads = max(1, min(128, int(opt_val)))
                            logging.info(f"Threads set to {search.threads}")
                        except ValueError:
                            pass
                    elif opt_name == "hash":
                        try:
                            if not (search_thread and search_thread.is_alive()):
                                search.set_hash_size(max(1, min(1024, int(opt_val))))
                                logging.info(f"Hash set to {opt_val} MB")
                        except ValueError:
                            pass
                    elif opt_name == "clear hash":
                        if not (search_thread and search_thread.is_alive()):
                            search.tt.clear()
                    elif opt_name == "move overhead":
                        try:
                            MOVE_OVERHEAD_MS = max(0, min(5000, int(opt_val)))
                        except ValueError:
                            pass
                    elif opt_name == "syzygypath":
                        # [UPGRADE] the path was lower-cased before, which breaks
                        # case-sensitive filesystems (Linux/Lichess hosts).
                        try:
                            TABLEBASES = _load_tablebases(raw_val)
                            search.tablebase = TABLEBASES
                            logging.info(f"Loaded Syzygy tablebases successfully from {raw_val}")
                        except Exception as e:
                            logging.error(f"Error loading Syzygy tablebases: {e}")
                    elif opt_name == "syzygyprobedepth":
                        try:
                            search.syzygy_probe_depth = int(opt_val)
                        except ValueError:
                            pass
                    elif opt_name == "syzygyprobelimit":
                        try:
                            search.syzygy_probe_limit = int(opt_val)
                        except ValueError:
                            pass
                    elif opt_name == "ponder":
                        PONDER_ENABLED = (opt_val == "true")
                        logging.info(f"Ponder enabled set to {PONDER_ENABLED}")
                    elif opt_name == "uselearnedweights":
                        search.set_learned_weights(opt_val == "true")
                        logging.info(f"UseLearnedWeights set to {opt_val}")
                            
            elif command == "ucinewgame":
                if search_thread and search_thread.is_alive():
                    stop_search_and_join(bump_id=True)
                _safe_tracker(tracker.start_new_game)
                board.reset()
                # [UPGRADE] also clears the TT, counter-moves and pawn cache
                search.new_game()
                
            elif command == "position":
                if search_thread and search_thread.is_alive():
                    if getattr(search, 'is_pondering', False):
                        logging.info("Ponder miss or interrupted by new position.")
                    stop_search_and_join(bump_id=True)
                    
                fen = None
                moves = []
                
                try:
                    if len(tokens) >= 2 and tokens[1] == "startpos":
                        board.reset()
                        if "moves" in tokens:
                            moves_start = tokens.index("moves")
                            moves = tokens[moves_start+1:]
                    elif len(tokens) >= 2 and tokens[1] == "fen":
                        if "moves" in tokens:
                            moves_start = tokens.index("moves")
                            fen = " ".join(tokens[2:moves_start])
                            moves = tokens[moves_start+1:]
                        else:
                            fen = " ".join(tokens[2:])
                        board.set_fen(fen)
                    else:
                        continue

                    for move in moves:
                        # [UPGRADE] push_uci() validates legality; a corrupt move
                        # list now raises here (and is logged) instead of silently
                        # building an impossible position.
                        board.push_uci(move)
                    _safe_tracker(tracker.update_position, fen, moves)
                except Exception as e:
                    logging.error(f"Error parsing position: {e}")
                    continue

            elif command == "go":
                if search_thread and search_thread.is_alive():
                    stop_search_and_join(bump_id=True)

                is_ponder = "ponder" in tokens
                if is_ponder and not PONDER_ENABLED:
                    is_ponder = False

                params = parse_go_args(tokens[1:])
                # [UPGRADE] never answer 'go ponder' with an immediate bestmove
                # (UCI forbids it); the book is only used for real moves.
                best_move = None if is_ponder else get_book_move(board)
                if best_move:
                    _safe_tracker(tracker.record_evaluation, len(board.move_stack), 0)
                    ponder_uci = ""
                    if PONDER_ENABLED:
                        board.push(best_move)
                        ponder_move = get_book_move(board)
                        if not ponder_move:
                            legal_fallbacks = list(board.legal_moves)
                            if legal_fallbacks:
                                ponder_move = legal_fallbacks[0]
                        if ponder_move:
                            ponder_uci = f" ponder {ponder_move.uci()}"
                        board.pop()
                    print(f"bestmove {best_move.uci()}{ponder_uci}", flush=True)
                    continue
                
                root_legal_moves = list(board.legal_moves)
                if not root_legal_moves:
                    print("bestmove 0000", flush=True)
                    continue
                    
                valid_ucis = {m.uci() for m in root_legal_moves}
                fallback_uci = root_legal_moves[0].uci()
                root_move_stack_len = len(board.move_stack)
                
                t_lim, d_lim, n_lim = calculate_time_limit(board, params)
                soft_lim = calculate_soft_limit(params, t_lim)
                SEARCH_ID += 1
                current_search_id = SEARCH_ID
                
                search.abort = False
                search.timeout = False

                def search_worker(search_board, time_lim, soft_lim, depth_lim, node_lim, s_id, valid_moves, fallback, stack_len, pondering):
                    search.is_pondering = pondering
                    if pondering:
                        logging.info("Pondering started.")

                    try:
                        best, ponder, score = search.iterative_deepening(
                            search_board, 
                            time_limit=time_lim, 
                            depth_limit=depth_lim, 
                            node_limit=node_lim,
                            soft_limit=soft_lim
                        )

                        # [UPGRADE] this wait used to be dead code because
                        # iterative_deepening() left search.abort == True.
                        if search.is_pondering and not search.abort:
                            logging.info("Ponder search finished by limits, waiting for ponderhit or stop.")
                            while search.is_pondering and not search.abort:
                                time.sleep(0.01)

                        if s_id == SEARCH_ID:
                            best_uci = best.uci() if best else fallback
                            if best_uci not in valid_moves:
                                logging.error(f"CRITICAL: Search output illegal move {best_uci}. Triggering fallback.")
                                best_uci = fallback
                            _safe_tracker(tracker.record_evaluation, stack_len, score)
                            
                            if ponder and PONDER_ENABLED:
                                print(f"bestmove {best_uci} ponder {ponder.uci()}", flush=True)
                                logging.info(f"bestmove printed with ponder move: {best_uci} ponder {ponder.uci()}")
                            else:
                                print(f"bestmove {best_uci}", flush=True)
                                logging.info(f"bestmove printed without ponder move: {best_uci}")
                        else:
                            logging.info("Stale search ignored due to SEARCH_ID mismatch.")
                    except Exception as e:
                        logging.error(f"Search error in thread: {str(e)}")
                        if s_id == SEARCH_ID:
                            print(f"bestmove {fallback}", flush=True)

                search_board = board.copy()
                search_thread = threading.Thread(
                    target=search_worker, 
                    args=(search_board, t_lim, soft_lim, d_lim, n_lim, current_search_id, valid_ucis, fallback_uci, root_move_stack_len, is_ponder)
                )
                search_thread.start()

            elif command == "ponderhit":
                if search_thread and search_thread.is_alive():
                    logging.info("ponderhit received, switching to normal time management.")
                    search.ponder_hit()

            elif command == "stop":
                if getattr(search, 'is_pondering', False):
                    logging.info("Pondering stopped via stop command.")
                search.abort = True
                search.timeout = True
                if search_thread and search_thread.is_alive():
                    search_thread.join()

            elif command == "quit":
                search.abort = True
                search.timeout = True
                if search_thread and search_thread.is_alive():
                    search_thread.join()
                _safe_tracker(tracker.save_current_game)
                break
                
        except Exception as e:
            logging.error(f"Engine error: {str(e)}")
            continue

if __name__ == "__main__":
    uci_loop()
