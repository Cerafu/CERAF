import chess
import chess.pgn
import datetime
import json
from src.search import Search
from src.storage import DIRS

MAX_GAME_PLIES = 400

def run_selfplay(games=10, depth=None, movetime=0.5):
    """Self-play data generation.

    [UPGRADE] `depth` used to be accepted but ignored. It is now an optional
    depth cap (default None = no cap, i.e. the previous behaviour of searching
    purely by time); `movetime` (seconds per move) is the old hard-coded 0.5.
    """
    print(f"Starting self-play loop for {games} games...")
    search_white = Search()
    search_black = Search()
    depth_limit = depth if depth else 100

    for i in range(games):
        # [UPGRADE] fresh TT/history per game (they carried over before), and the
        # sticky `abort` flag that made every search after the first return
        # instantly with the first legal move is fixed in Search itself.
        search_white.new_game()
        search_black.new_game()

        board = chess.Board()
        game = chess.pgn.Game()
        game.headers["Event"] = "CERAF Self-Play Generation"
        game.headers["Date"] = datetime.datetime.now().strftime("%Y.%m.%d")
        game.headers["White"] = "CERAF_Current v2.0"
        game.headers["Black"] = "CERAF_Current v2.0"
        
        node = game
        positions = []
        
        # claim_draw=True so threefold repetition / 50-move draws end the game
        # (the engine already scores 2-fold repetitions as draws).
        while not board.is_game_over(claim_draw=True) and len(board.move_stack) < MAX_GAME_PLIES:
            if board.turn == chess.WHITE:
                move, _, score = search_white.iterative_deepening(board, time_limit=movetime, depth_limit=depth_limit) 
            else:
                move, _, score = search_black.iterative_deepening(board, time_limit=movetime, depth_limit=depth_limit)
            
            if not move:
                break
                
            positions.append((board.fen(), move.uci(), score))
            board.push(move)
            node = node.add_variation(move)
        
        result = board.result(claim_draw=True)
        game.headers["Result"] = result
        
        pgn_path = DIRS["selfplay"] / f"selfplay_batch_{datetime.datetime.now().strftime('%Y%m%d')}.pgn"
        with open(pgn_path, "a", encoding="utf-8") as f:
            f.write(str(game) + "\n\n")
            
        training_records = []
        for fen, move_str, score in positions:
            record = {
                "fen": fen,
                "move": move_str,
                "eval": score,
                "game_result": result,
                "timestamp": datetime.datetime.now().isoformat()
            }
            training_records.append(record)
            
        training_path = DIRS["training"] / "lichess_training_data.jsonl"
        with open(training_path, "a") as f:
            for rec in training_records:
                f.write(json.dumps(rec) + "\n")
                
        print(f"Game {i+1}/{games} completed. Result: {result} | Extracted {len(positions)} positions.")
