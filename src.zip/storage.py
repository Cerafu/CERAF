import os
import json
import logging
from pathlib import Path
from datetime import datetime

# [UPGRADE] The root can be overridden with the CERAF_HOME environment variable.
# The hard-coded Windows path is still the default, so the existing D:\Chess
# layout keeps working. On Linux (e.g. a Lichess host) the old default became a
# literal relative folder called "D:\Chess" inside the working directory.
BASE_DIR = Path(os.environ.get("CERAF_HOME", r"D:\Chess"))
DIRS = {
    "books": BASE_DIR / "Books",
    "syzygy": BASE_DIR / "Syzygy",
    "pgns": BASE_DIR / "PGNs",
    "selfplay": BASE_DIR / "SelfPlay",
    "training": BASE_DIR / "Training",
    "models": BASE_DIR / "Models",
    "logs": BASE_DIR / "Logs",
    "benchmarks": BASE_DIR / "Benchmarks",
    "backups": BASE_DIR / "Backups",
}

def setup_directories():
    for name, path in DIRS.items():
        path.mkdir(parents=True, exist_ok=True)
    setup_logging()

def setup_logging():
    log_file = DIRS["logs"] / f"ceraf_engine_{datetime.now().strftime('%Y%m%d')}.log"
    logging.basicConfig(filename=log_file, level=logging.INFO, 
                        format='%(asctime)s - %(levelname)s - %(message)s')

def load_model():
    model_path = DIRS["models"] / "latest_model.json"
    if model_path.exists():
        # [UPGRADE] a corrupt/half-written model file must not crash the engine
        # or the tuner; treat it as "no model".
        try:
            with open(model_path, 'r') as f:
                data = json.load(f)
            if isinstance(data, dict):
                return data
            logging.error(f"Model file {model_path} is not a JSON object; ignoring it.")
        except (OSError, ValueError) as e:
            logging.error(f"Could not read model file {model_path}: {e}")
    return None

def save_model(weights, version_name="latest"):
    model_path = DIRS["models"] / f"{version_name}_model.json"
    
    if version_name == "latest" and model_path.exists():
        backup_path = DIRS["backups"] / f"model_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        model_path.rename(backup_path)

    with open(model_path, 'w') as f:
        json.dump(weights, f, indent=4)
    logging.info(f"Model saved to {model_path}")

def save_training_data(data_records):
    filename = DIRS["training"] / f"data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jsonl"
    with open(filename, 'w') as f:
        for record in data_records:
            f.write(json.dumps(record) + '\n')
