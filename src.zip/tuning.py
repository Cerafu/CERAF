import copy
import json
import logging
import math
import random
from src.storage import load_model, save_model, DIRS
from src.evaluation import DEFAULT_WEIGHTS, Evaluator
import chess

# [UPGRADE] safety limits for the tuner
MIN_POSITIONS = 1000        # was 10: far too few for 14 free parameters
MAX_DRIFT = 0.30            # a parameter may move at most +-30% away from its default
MIN_DRIFT_CP = 25           # ...or 25 cp, whichever is larger
SKIP_OPENING_FULLMOVES = 8  # opening positions are book/theory, not eval signal
VALIDATION_FRACTION = 0.2

def sigmoid(score, scale=400.0):
    try:
        return 1 / (1 + math.exp(-score / scale))
    except OverflowError:
        return 0.0 if score < 0 else 1.0

def prepare_dataset(dataset):
    """[UPGRADE] Convert raw JSON records to (board, actual_result) pairs ONCE.
    The old code rebuilt chess.Board(fen) for every position on every candidate
    evaluation. Positions that a static evaluator cannot judge (side to move in
    check, the recorded move is a capture/promotion, or still in the opening)
    are dropped, which is the standard 'quiet position' filter for Texel tuning."""
    prepared = []
    for record in dataset:
        result_str = record.get("game_result", "*")
        if result_str == "*":
            continue
        fen = record.get("fen")
        if not fen:
            continue
        if result_str == "1-0":
            actual = 1.0
        elif result_str == "0-1":
            actual = 0.0
        else:
            actual = 0.5
        try:
            board = chess.Board(fen)
            if board.is_check() or board.fullmove_number <= SKIP_OPENING_FULLMOVES:
                continue
            move_str = record.get("move")
            if move_str:
                mv = chess.Move.from_uci(move_str)
                if board.is_capture(mv) or mv.promotion:
                    continue
        except Exception:
            continue
        prepared.append((board, actual))
    return prepared

def calculate_prepared_mse(weights, prepared, scale=400.0):
    if not prepared:
        return float('inf')
    temp_evaluator = Evaluator(weights=weights)
    total_error = 0.0
    for board, actual in prepared:
        score = temp_evaluator.evaluate(board)
        if board.turn == chess.BLACK:
            score = -score
        total_error += (sigmoid(score, scale) - actual) ** 2
    return total_error / len(prepared)

def calculate_dataset_mse(weights, dataset, scale=400.0):
    """Original public entry point (raw JSON records in, mean squared error out)."""
    prepared = []
    for record in dataset:
        result_str = record.get("game_result", "*")
        if result_str == "*":
            continue
        actual = 1.0 if result_str == "1-0" else (0.0 if result_str == "0-1" else 0.5)
        try:
            board = chess.Board(record.get("fen"))
        except Exception:
            continue
        prepared.append((board, actual))
    return calculate_prepared_mse(weights, prepared, scale)

def fit_scale(weights, prepared):
    """[UPGRADE] Texel tuning first fits the sigmoid scale (the 'K' constant) to
    the CURRENT evaluation; the old code hard-coded 400 so every weight was being
    pulled towards an arbitrary scaling instead of towards the data."""
    best_scale, best_mse = 400.0, calculate_prepared_mse(weights, prepared, 400.0)
    for scale in (150, 200, 250, 300, 350, 450, 500, 600, 700, 800, 1000):
        mse = calculate_prepared_mse(weights, prepared, float(scale))
        if mse < best_mse:
            best_scale, best_mse = float(scale), mse
    return best_scale

def _within_drift(category, param_str, value):
    default = DEFAULT_WEIGHTS.get(category, {}).get(param_str)
    if default is None:
        return True
    limit = max(MIN_DRIFT_CP, abs(default) * MAX_DRIFT)
    return abs(value - default) <= limit

def run_tuning():
    print("Initializing Texel Parameter Tuning...")
    logging.info("Starting Texel tuning session...")
    
    training_path = DIRS["training"] / "lichess_training_data.jsonl"
    if not training_path.exists():
        print(f"No training data found at {training_path}")
        print("Play games on Lichess or run self-play first to generate data!")
        return
        
    dataset = []
    with open(training_path, "r") as f:
        for line in f:
            if line.strip():
                try:
                    dataset.append(json.loads(line))
                except ValueError:
                    continue   # [UPGRADE] skip truncated/corrupt lines instead of crashing
                
    prepared = prepare_dataset(dataset)
    if len(prepared) < MIN_POSITIONS:
        print(f"Only {len(prepared)} usable quiet positions (need at least {MIN_POSITIONS}). Collect more games before tuning.")
        return
        
    print(f"Loaded {len(dataset)} records, {len(prepared)} usable quiet positions.")

    # [UPGRADE] hold out 20% of positions: a change is only kept if it lowers the
    # error on data the tuner did NOT fit, which guards against overfitting.
    rng = random.Random(1234)
    rng.shuffle(prepared)
    n_val = max(1, int(len(prepared) * VALIDATION_FRACTION))
    validation, training = prepared[:n_val], prepared[n_val:]
    
    current_weights = load_model() or DEFAULT_WEIGHTS
    scale = fit_scale(current_weights, training)
    print(f"Fitted sigmoid scale: {scale:.0f}")
    best_mse = calculate_prepared_mse(current_weights, training, scale)
    baseline_val = calculate_prepared_mse(current_weights, validation, scale)
    print(f"Current Model Baseline MSE: train {best_mse:.6f} | validation {baseline_val:.6f}")
    
    temp_weights = copy.deepcopy(current_weights)
    converged = False
    
    while not converged:
        improved = False
        
        for category in temp_weights.keys():
            for param_str in list(temp_weights[category].keys()):
                if param_str == str(chess.KING) or param_str == str(chess.PAWN): 
                    continue
                    
                for adjustment in [-10, 10]:
                    candidate_weights = copy.deepcopy(temp_weights)
                    candidate_weights[category][param_str] += adjustment
                    if not _within_drift(category, param_str, candidate_weights[category][param_str]):
                        continue
                    
                    candidate_mse = calculate_prepared_mse(candidate_weights, training, scale)
                    
                    if candidate_mse < best_mse:
                        best_mse = candidate_mse
                        temp_weights = candidate_weights
                        improved = True
                        print(f"  Improved! Param {param_str} ({category}) adjusted by {adjustment:+} | New MSE: {best_mse:.6f}")
        
        if not improved:
            converged = True

    final_val = calculate_prepared_mse(temp_weights, validation, scale)
    print(f"Validation MSE: baseline {baseline_val:.6f} -> tuned {final_val:.6f}")
    if final_val < baseline_val:
        print("Saving tuned model (improved on held-out data)...")
        save_model(temp_weights, version_name="latest")
        logging.info(f"Texel Tuning updated weights. Train MSE: {best_mse:.6f}, validation {baseline_val:.6f} -> {final_val:.6f}")
    else:
        print("Tuned weights did NOT improve on held-out data; keeping the existing model.")
        logging.info("Texel tuning rejected: no improvement on validation set.")
            
    print("Optimization complete! Reached local minimum.")
