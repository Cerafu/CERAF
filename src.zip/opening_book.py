import chess
import chess.polyglot
import logging
import random
from src.storage import DIRS

class OpeningBook:
    def __init__(self):
        self.readers = []
        self._load_books()

    def _load_books(self):
        bin_files = list(DIRS["books"].glob("*.bin"))
        if not bin_files:
            logging.warning("No .bin files found in Books directory.")
            return

        for book_path in bin_files:
            try:
                reader = chess.polyglot.open_reader(str(book_path))
                self.readers.append(reader)
                logging.info(f"Loaded opening book: {book_path.name}")
            except Exception as e:
                logging.error(f"Failed to load {book_path.name}: {e}")

    def get_move(self, board: chess.Board, min_weight: int = 1, tournament_mode: bool = True):
        if not self.readers:
            return None

        aggregated_moves = {}

        for reader in self.readers:
            try:
                for entry in reader.find_all(board):
                    if entry.move in board.legal_moves:
                        if entry.move not in aggregated_moves:
                            aggregated_moves[entry.move] = 0
                        aggregated_moves[entry.move] += entry.weight
            except Exception as e:
                logging.error(f"Book probing error: {e}")

        if not aggregated_moves:
            return None

        valid_moves = []
        valid_weights = []

        for move, weight in aggregated_moves.items():
            if weight >= min_weight:
                valid_moves.append(move)
                valid_weights.append(weight)

        if not valid_moves:
            best_move = max(aggregated_moves.items(), key=lambda x: x[1])[0]
            logging.info(f"Book fallback (highest weight): {best_move.uci()}")
            return best_move

        if tournament_mode:
            valid_weights = [w ** 2 for w in valid_weights]

        chosen_move = random.choices(valid_moves, weights=valid_weights, k=1)[0]
        logging.info(f"Book move chosen: {chosen_move.uci()} (Pool: {len(valid_moves)} moves)")
        
        return chosen_move

    def close(self):
        for reader in self.readers:
            try:
                reader.close()
            except Exception as e:
                logging.error(f"Error closing book: {e}")

book = OpeningBook()

def get_book_move(board: chess.Board):
    return book.get_move(board)