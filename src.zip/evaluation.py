import chess

DEFAULT_WEIGHTS = {
    "mg_material": {
        str(chess.PAWN): 82, str(chess.KNIGHT): 337, str(chess.BISHOP): 365, 
        str(chess.ROOK): 477, str(chess.QUEEN): 1025, str(chess.KING): 0
    },
    "eg_material": {
        str(chess.PAWN): 94, str(chess.KNIGHT): 281, str(chess.BISHOP): 297, 
        str(chess.ROOK): 512, str(chess.QUEEN): 936, str(chess.KING): 0
    },
    "mg_bonuses": { "bishop_pair": 45 },
    "eg_bonuses": { "bishop_pair": 65 }
}

def _flip(table):
    flipped = []
    for r in reversed(range(8)):
        flipped.extend(table[r*8:(r+1)*8])
    return flipped

class Evaluator:
    MG_VALUES = { chess.PAWN: 82, chess.KNIGHT: 337, chess.BISHOP: 365, chess.ROOK: 477, chess.QUEEN: 1025, chess.KING: 0 }
    EG_VALUES = { chess.PAWN: 94, chess.KNIGHT: 281, chess.BISHOP: 297, chess.ROOK: 512, chess.QUEEN: 936, chess.KING: 0 }

    ATTACK_WEIGHTS = { chess.PAWN: 0, chess.KNIGHT: 2, chess.BISHOP: 2, chess.ROOK: 3, chess.QUEEN: 5, chess.KING: 0 }
    
    # Advanced Mobility Tables (Indexed by number of safe legal attacks)
    MOBILITY_BONUS = {
        chess.KNIGHT:  ([-30, -10,  0,  5, 10, 15, 20, 25, 30], [-30, -10,  0,  5, 10, 15, 20, 25, 30]),
        chess.BISHOP:  ([-25, -11,  0,  7, 14, 21, 28, 35, 42, 49, 56, 63, 70, 77], [-25, -11,  0,  7, 14, 21, 28, 35, 42, 49, 56, 63, 70, 77]),
        chess.ROOK:    ([-20, -10,  0,  4,  8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48], [-20, -10,  0,  4,  8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48]),
        chess.QUEEN:   ([-10,  -5,  0,  2,  4,  6,  8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50], [-10,  -5,  0,  2,  4,  6,  8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50])
    }

    # Positional Tables
    MG_PAWN_RAW = [
          0,   0,   0,   0,   0,   0,   0,   0,
         98, 134,  61,  95,  68, 126,  34, -11,
        -6,    7,  26,  31,  65,  56,  25, -20,
        -14,  13,   6,  21,  23,  12,  17, -23,
        -27,  -2,  -5,  12,  17,   6,  10, -25,
        -26,  -4,  -4, -10,   3,   3,  33, -12,
        -35,  -1, -20, -23, -15,  24,  38, -22,
          0,   0,   0,   0,   0,   0,   0,   0
    ]
    MG_KNIGHT_RAW = [
       -167, -89, -34, -49,  61, -97, -15, -107,
        -73, -41,  72,  36,  23,  62,   7,  -17,
        -47,  60,  37,  65,  84, 129,  73,   44,
         -9,  17,  19,  53,  37,  69,  18,   22,
        -13,   4,  16,  13,  28,  19,  21,   -8,
        -23,  -9,  12,  10,  19,  17,  25,  -16,
        -29, -53, -12,  -3,  -1,  18, -14, -19,
       -105, -21, -58, -33, -17, -28, -19,  -23
    ]
    MG_BISHOP_RAW = [
        -29,   4, -82, -37, -25, -42,   7,  -8,
        -26,  16, -18, -13,  30,  59,  18, -47,
        -16,  37,  43,  40,  35,  50,  37,  -2,
         -4,   5,  19,  50,  37,  37,   7,  -2,
         -6,  13,  13,  26,  34,  12,  10,   4,
          0,  15,  15,  15,  14,  27,  18,  10,
          4,  15,  16,   0,   7,  21,  33,   1,
        -33,  -3, -14, -21, -13, -12, -39, -21
    ]
    MG_ROOK_RAW = [
         32,  42,  32,  51,  63,  9,  31,  43,
         27,  32,  58,  62,  80, 67,  26,  44,
         -5,  19,  26,  36,  17, 45,  61,  16,
        -24, -11,   7,  26,  24, 35,  -8, -20,
        -36, -26, -12,  -1,   9, -7,   6, -23,
        -45, -25, -16, -17,   3,  0,  -5, -33,
        -44, -16, -20,  -9,  -1, 11,  -6, -71,
        -19, -13,   1,  17,  16,  7, -37, -26
    ]
    MG_QUEEN_RAW = [
        -28,   0,  29,  12,  59,  44,  43,  45,
        -24, -39,  -5,   1, -16,  57,  28,  54,
        -13, -17,   7,   8,  29,  56,  47,  57,
        -27, -27, -16, -16,  -1,  17,  -2,   1,
         -9, -26,  -9, -10,  -2,  -4,   3,  -3,
        -14,   2, -11,  -2,  -5,   2,  14,   5,
        -35,  -8,  11,   2,   8,  15,  -3,   1,
         -1, -18,  -9,  10, -15, -25, -31, -50
    ]
    MG_KING_RAW = [
        -65,  23,  16, -15, -56, -34,   2,  13,
         29,  -1, -20,  -7,  -8,  -4, -38, -29,
         -9,  24,   2, -16, -20,   6,  22, -22,
        -17, -20, -12, -27, -30, -25, -14, -36,
        -49,  -1, -27, -39, -46, -44, -33, -51,
        -14, -14, -22, -46, -44, -30, -15, -27,
          1,   7,  -8, -64, -43, -16,   9,   8,
        -15,  36,  12, -54,   8, -28,  24,  14
    ]

    EG_PAWN_RAW = [
          0,   0,   0,   0,   0,   0,   0,   0,
        178, 173, 158, 134, 147, 132, 165, 187,
         94, 100,  85,  67,  56,  53,  82,  84,
         32,  24,  13,   5,  -2,   4,  17,  17,
         13,   9,  -3,  -7,  -7,  -8,   3,  -1,
          4,   7,  -6,   1,   0,  -5,  -1,  -8,
         13,   8,   8,  10,  13,   0,   2,  -7,
          0,   0,   0,   0,   0,   0,   0,   0
    ]
    EG_KNIGHT_RAW = [
        -58, -38, -13, -28, -31, -27, -63, -99,
        -25,  -8, -25,  -2,  -9, -25, -24, -52,
        -24, -20,  10,   9,  -1,  -9, -19, -41,
        -17,   3,  22,  22,  22,  11,   8, -18,
        -18,  -6,  16,  25,  16,  17,   4, -18,
        -23,  -3,  -1,  15,  10,  -3, -20, -22,
        -42, -20, -10,  -5,  -2, -20, -23, -44,
        -29, -51, -23, -38, -29, -27, -43, -36
    ]
    EG_BISHOP_RAW = [
        -14, -21, -11,  -8,  -7,  -9, -17, -24,
         -8,  -4,   7, -12,  -3, -13,  -4, -14,
          2,  -8,   0,  -1,  -2,   6,   0,   4,
         -3,   9,  12,   9,  14,  10,   3,   2,
         -6,   3,  13,  19,   7,  10,  -3,  -9,
        -12,  -3,   8,  10,  13,   3,  -7, -15,
        -14, -18,  -7,  -1,   4,  -9, -15, -27,
        -23,  -9, -23,  -5,  -9, -16,  -5, -17
    ]
    EG_ROOK_RAW = [
         13,  10,  18,  15,  12,  12,   8,   5,
         11,  13,  13,  11,  -3,   3,   8,   3,
          7,   7,   7,   5,   4,  -3,  -5,  -3,
          4,   3,  13,   1,   2,   1,  -1,   2,
          3,   5,   8,   4,  -5,  -6,  -8, -11,
         -4,   0,  -5,  -1,  -7, -12,  -8, -16,
         -6,  -6,   0,   2,  -9,  -9, -11,  -3,
         -9,   2,   3,  -1,  -5, -13,   4, -20
    ]
    EG_QUEEN_RAW = [
         -9,  22,  22,  27,  27,  19,  10,  20,
        -17,  20,  32,  41,  58,  25,  30,   0,
        -20,   6,   9,  49,  47,  35,  19,   9,
          3,  22,  24,  45,  57,  40,  57,  36,
        -18,  28,  19,  47,  31,  34,  39,  23,
        -16, -27,  15,   6,   9,  17,  10,   5,
        -22, -23, -30, -16, -16, -23, -36, -32,
        -33, -28, -22, -43,  -5, -32, -20, -41
    ]
    EG_KING_RAW = [
        -74, -35, -18, -18, -11,  15,   4, -17,
        -12,  17,  14,  17,  17,  38,  23,  11,
         10,  17,  23,  15,  20,  45,  44,  13,
         -8,  22,  24,  27,  26,  33,  26,   3,
        -18,  -4,  21,  24,  27,  23,   9, -11,
        -19,  -3,  11,  21,  23,  16,   7,  -9,
        -27, -11,   4,  13,  14,   4,  -5, -17,
        -53, -34, -21, -11, -28, -14, -24, -43
    ]

    PST_MG = { chess.PAWN: _flip(MG_PAWN_RAW), chess.KNIGHT: _flip(MG_KNIGHT_RAW), chess.BISHOP: _flip(MG_BISHOP_RAW), chess.ROOK: _flip(MG_ROOK_RAW), chess.QUEEN: _flip(MG_QUEEN_RAW), chess.KING: _flip(MG_KING_RAW) }
    PST_EG = { chess.PAWN: _flip(EG_PAWN_RAW), chess.KNIGHT: _flip(EG_KNIGHT_RAW), chess.BISHOP: _flip(EG_BISHOP_RAW), chess.ROOK: _flip(EG_ROOK_RAW), chess.QUEEN: _flip(EG_QUEEN_RAW), chess.KING: _flip(EG_KING_RAW) }

    MG_PASSED_BONUS = [0, 10, 30, 52, 78, 115, 162, 0]
    EG_PASSED_BONUS = [0, 22, 55, 88, 142, 215, 290, 0]

    # [UPGRADE] King Pawn Shield Constants
    SHIELD_MISSING = 25
    SHIELD_MOVED = 10
    FILE_OPEN_NEAR_KING = 15
    
    # [UPGRADE 2.0] Connected Rooks Bonus
    CONNECTED_ROOKS_MG = 20
    CONNECTED_ROOKS_EG = 25
    
    # Rank Masks for PyPy bitwise speed
    RANK_2_MASK = 0x000000000000FF00
    RANK_3_MASK = 0x0000000000FF0000
    RANK_6_MASK = 0x0000FF0000000000
    RANK_7_MASK = 0x00FF000000000000

    FILE_MASKS = [chess.BB_FILES[i] for i in range(8)]
    ADJACENT_FILE_MASKS = []
    for i in range(8):
        mask = 0
        if i > 0: mask |= chess.BB_FILES[i-1]
        if i < 7: mask |= chess.BB_FILES[i+1]
        ADJACENT_FILE_MASKS.append(mask)

    WHITE_PASSED_MASKS = []
    BLACK_PASSED_MASKS = []
    KING_ZONE_MASKS = []

    for sq in range(64):
        file, rank = chess.square_file(sq), chess.square_rank(sq)
        w_mask = chess.BB_EMPTY
        for r in range(rank + 1, 8):
            for f in range(max(0, file - 1), min(8, file + 2)):
                w_mask |= chess.BB_SQUARES[chess.square(f, r)]
        WHITE_PASSED_MASKS.append(w_mask)
        
        b_mask = chess.BB_EMPTY
        for r in range(0, rank):
            for f in range(max(0, file - 1), min(8, file + 2)):
                b_mask |= chess.BB_SQUARES[chess.square(f, r)]
        BLACK_PASSED_MASKS.append(b_mask)

        kz_mask = chess.BB_SQUARES[sq]
        for f in range(max(0, file - 1), min(8, file + 2)):
            for r in range(max(0, rank - 1), min(8, rank + 2)):
                kz_mask |= chess.BB_SQUARES[chess.square(f, r)]
        KING_ZONE_MASKS.append(kz_mask)

    # King Safety Tables 
    KING_SAFETY_TABLE = [
          0,   0,   5,  10,  18,  28,  40,  55,  72,  92, 115, 141, 170, 202, 237, 275,
        316, 360, 407, 457, 510, 566, 625, 687, 752, 820, 891, 965, 1042, 1122, 1205, 1291
    ]

    # [UPGRADE] Pawn-structure results are cached by (white pawns, black pawns).
    # Pawn structure changes rarely during search, so most evaluations hit the cache.
    PAWN_CACHE_LIMIT = 1 << 16
    FULL_BB = 0xFFFFFFFFFFFFFFFF

    def __init__(self, weights=None):
        self.pawn_cache = {}
        self.set_weights(weights)

    def set_weights(self, weights=None):
        """(Re)load material / bonus weights and rebuild the combined
        material+PST lookup tables used by evaluate()."""
        self.weights = weights
        self.mg_values = self.MG_VALUES.copy()
        self.eg_values = self.EG_VALUES.copy()
        self.mg_bonuses = {}
        self.eg_bonuses = {}

        if weights:
            mg_vals = {int(k): v for k, v in weights.get("mg_material", {}).items()}
            eg_vals = {int(k): v for k, v in weights.get("eg_material", {}).items()}
            self.mg_values.update(mg_vals)
            self.eg_values.update(eg_vals)
            self.mg_bonuses = weights.get("mg_bonuses", {})
            self.eg_bonuses = weights.get("eg_bonuses", {})

        self.bishop_pair_mg = self.mg_bonuses.get("bishop_pair", 45)
        self.bishop_pair_eg = self.eg_bonuses.get("bishop_pair", 65)

        # [UPGRADE] material + PST merged into one list per colour/piece so the
        # hot loop does one lookup instead of two additions and a dict access.
        # Index 0 is unused; black tables are pre-mirrored (sq ^ 56).
        self._w_mg = [None] * 7
        self._w_eg = [None] * 7
        self._b_mg = [None] * 7
        self._b_eg = [None] * 7
        for pt in range(1, 7):
            self._w_mg[pt] = [self.mg_values[pt] + self.PST_MG[pt][s] for s in range(64)]
            self._w_eg[pt] = [self.eg_values[pt] + self.PST_EG[pt][s] for s in range(64)]
            self._b_mg[pt] = [self.mg_values[pt] + self.PST_MG[pt][s ^ 56] for s in range(64)]
            self._b_eg[pt] = [self.eg_values[pt] + self.PST_EG[pt][s ^ 56] for s in range(64)]
        self.pawn_cache.clear()

    def _pawn_terms(self, wp, bp):
        """Doubled / isolated / backward / passed pawn terms for both sides.
        Depends only on the two pawn bitboards, so it is cached.
        Returns (white_mg, white_eg, black_mg, black_eg) adjustments."""
        key = (wp << 64) | bp
        cached = self.pawn_cache.get(key)
        if cached is not None:
            return cached

        popcount = chess.popcount
        FILE_MASKS = self.FILE_MASKS
        ADJ = self.ADJACENT_FILE_MASKS
        w_mg = w_eg = b_mg = b_eg = 0

        for f in range(8):
            file_mask = FILE_MASKS[f]
            adj_mask = ADJ[f]

            w_file = wp & file_mask
            b_file = bp & file_mask
            w_count = popcount(w_file) if w_file else 0
            b_count = popcount(b_file) if b_file else 0
            w_adj = wp & adj_mask
            b_adj = bp & adj_mask

            # Doubled pawns
            if w_count > 1:
                w_mg -= 16 * (w_count - 1)
                w_eg -= 22 * (w_count - 1)
            if b_count > 1:
                b_mg -= 16 * (b_count - 1)
                b_eg -= 22 * (b_count - 1)

            # Isolated pawns
            if w_count > 0 and not w_adj:
                w_mg -= 14 * w_count
                w_eg -= 14 * w_count
            if b_count > 0 and not b_adj:
                b_mg -= 14 * b_count
                b_eg -= 14 * b_count

            # Backward pawns (single pawn on file, no neighbouring pawn behind it,
            # stop square occupied by an enemy pawn)
            if w_count == 1:
                w_rank = (w_file & -w_file).bit_length() - 1 >> 3
                if w_rank < 7 and not (w_adj & ((1 << (8 * w_rank)) - 1)):
                    if bp & (1 << (8 * (w_rank + 1) + f)):
                        w_mg -= 10
                        w_eg -= 12
            if b_count == 1:
                b_rank = (b_file & -b_file).bit_length() - 1 >> 3
                if b_rank > 0 and not (b_adj & (self.FULL_BB & ~((1 << (8 * (b_rank + 1))) - 1))):
                    if wp & (1 << (8 * (b_rank - 1) + f)):
                        b_mg -= 10
                        b_eg -= 12

        # Passed pawns
        MG_PASSED = self.MG_PASSED_BONUS
        EG_PASSED = self.EG_PASSED_BONUS
        bb = wp
        while bb:
            lsb = bb & -bb
            sq = lsb.bit_length() - 1
            bb ^= lsb
            if not (bp & self.WHITE_PASSED_MASKS[sq]):
                rank = sq >> 3
                w_mg += MG_PASSED[rank]
                w_eg += EG_PASSED[rank]
        bb = bp
        while bb:
            lsb = bb & -bb
            sq = lsb.bit_length() - 1
            bb ^= lsb
            if not (wp & self.BLACK_PASSED_MASKS[sq]):
                rank = 7 - (sq >> 3)
                b_mg += MG_PASSED[rank]
                b_eg += EG_PASSED[rank]

        result = (w_mg, w_eg, b_mg, b_eg)
        if len(self.pawn_cache) >= self.PAWN_CACHE_LIMIT:
            self.pawn_cache.clear()
        self.pawn_cache[key] = result
        return result

    def evaluate(self, board: chess.Board) -> int:
        """Static evaluation in centipawns from the side-to-move's perspective.

        [UPGRADE] Same terms and weights as before, but computed straight from
        the bitboards: no piece_map()/Piece/SquareSet allocation, no 64-square
        scans, and pawn structure comes from a cache."""
        popcount = chess.popcount
        occ = board.occupied
        occ_w = board.occupied_co[chess.WHITE]
        occ_b = board.occupied_co[chess.BLACK]
        pawns = board.pawns
        knights = board.knights
        bishops = board.bishops
        rooks = board.rooks
        queens = board.queens
        kings = board.kings

        wp = pawns & occ_w
        bp = pawns & occ_b

        current_phase = min(24, popcount(knights | bishops) + 2 * popcount(rooks) + 4 * popcount(queens))
        phase = (current_phase * 256) // 24

        w_king_sq = board.king(chess.WHITE)
        b_king_sq = board.king(chess.BLACK)
        w_kz = self.KING_ZONE_MASKS[w_king_sq] if w_king_sq is not None else 0
        b_kz = self.KING_ZONE_MASKS[b_king_sq] if b_king_sq is not None else 0

        ATTACK_W = self.ATTACK_WEIGHTS
        MOB = self.MOBILITY_BONUS
        FILE_MASKS = self.FILE_MASKS
        KNIGHT_ATT = chess.BB_KNIGHT_ATTACKS
        DIAG_ATT = chess.BB_DIAG_ATTACKS
        DIAG_MASK = chess.BB_DIAG_MASKS
        FILE_ATT = chess.BB_FILE_ATTACKS
        FILE_MASK = chess.BB_FILE_MASKS
        RANK_ATT = chess.BB_RANK_ATTACKS
        RANK_MASK = chess.BB_RANK_MASKS
        KNIGHT, BISHOP, ROOK, QUEEN = chess.KNIGHT, chess.BISHOP, chess.ROOK, chess.QUEEN

        mg = [0, 0]
        eg = [0, 0]
        king_attack = [0, 0]  # king_attack[c] = attack weight c's pieces put on the ENEMY king zone
        piece_sets = ((KNIGHT, knights), (BISHOP, bishops), (ROOK, rooks), (QUEEN, queens))

        for ci in (0, 1):
            if ci == 0:
                own, mg_tab, eg_tab = occ_w, self._w_mg, self._w_eg
                enemy_kz, own_p, enemy_p = b_kz, wp, bp
                seventh = 6
            else:
                own, mg_tab, eg_tab = occ_b, self._b_mg, self._b_eg
                enemy_kz, own_p, enemy_p = w_kz, bp, wp
                seventh = 1
            c_mg = 0
            c_eg = 0
            atk = 0

            # Pawns and kings: material + PST only
            t_mg = mg_tab[chess.PAWN]
            t_eg = eg_tab[chess.PAWN]
            bb = own_p
            while bb:
                lsb = bb & -bb
                sq = lsb.bit_length() - 1
                bb ^= lsb
                c_mg += t_mg[sq]
                c_eg += t_eg[sq]
            t_mg = mg_tab[chess.KING]
            t_eg = eg_tab[chess.KING]
            bb = kings & own
            while bb:
                lsb = bb & -bb
                sq = lsb.bit_length() - 1
                bb ^= lsb
                c_mg += t_mg[sq]
                c_eg += t_eg[sq]

            # Knights, bishops, rooks, queens
            for pt, type_bb in piece_sets:
                bb = type_bb & own
                if not bb:
                    continue
                t_mg = mg_tab[pt]
                t_eg = eg_tab[pt]
                mob_mg, mob_eg = MOB[pt]
                mob_max = len(mob_mg) - 1
                aw = ATTACK_W[pt]
                while bb:
                    lsb = bb & -bb
                    sq = lsb.bit_length() - 1
                    bb ^= lsb
                    c_mg += t_mg[sq]
                    c_eg += t_eg[sq]

                    if pt == KNIGHT:
                        attacks = KNIGHT_ATT[sq]
                    elif pt == BISHOP:
                        attacks = DIAG_ATT[sq][DIAG_MASK[sq] & occ]
                    elif pt == ROOK:
                        attacks = RANK_ATT[sq][RANK_MASK[sq] & occ] | FILE_ATT[sq][FILE_MASK[sq] & occ]
                    else:
                        attacks = (DIAG_ATT[sq][DIAG_MASK[sq] & occ]
                                   | RANK_ATT[sq][RANK_MASK[sq] & occ]
                                   | FILE_ATT[sq][FILE_MASK[sq] & occ])

                    idx = popcount(attacks & ~own)
                    if idx > mob_max:
                        idx = mob_max
                    c_mg += mob_mg[idx]
                    c_eg += mob_eg[idx]
                    if attacks & enemy_kz:
                        atk += aw

                    if pt == ROOK:
                        f_mask = FILE_MASKS[sq & 7]
                        own_on_file = own_p & f_mask
                        enemy_on_file = enemy_p & f_mask
                        if not own_on_file and not enemy_on_file:
                            c_mg += 25  # open file
                            c_eg += 15
                        elif not own_on_file and enemy_on_file:
                            c_mg += 12  # semi-open
                            c_eg += 8
                        if (sq >> 3) == seventh:
                            c_mg += 35
                            c_eg += 45

            mg[ci] = c_mg
            eg[ci] = c_eg
            king_attack[ci] = atk

        white_mg, black_mg = mg
        white_eg, black_eg = eg

        # Table-based scaled quadratic king safety (penalty lands on the attacked side)
        KS = self.KING_SAFETY_TABLE
        ks_max = len(KS) - 1
        if king_attack[1] > 0:
            white_mg -= KS[min(king_attack[1], ks_max)]
        if king_attack[0] > 0:
            black_mg -= KS[min(king_attack[0], ks_max)]

        # King pawn shield (MG only)
        if w_king_sq is not None:
            w_kf = w_king_sq & 7
            if w_kf <= 2 or w_kf >= 5:
                for f in range(max(0, w_kf - 1), min(8, w_kf + 2)):
                    file_mask = FILE_MASKS[f]
                    w_on_file = wp & file_mask
                    if not w_on_file:
                        white_mg -= self.SHIELD_MISSING
                        if not (bp & file_mask):
                            white_mg -= self.FILE_OPEN_NEAR_KING
                    else:
                        if not (w_on_file & self.RANK_2_MASK):
                            white_mg -= self.SHIELD_MOVED
                            if w_on_file & self.RANK_3_MASK:
                                white_mg += 5

        if b_king_sq is not None:
            b_kf = b_king_sq & 7
            if b_kf <= 2 or b_kf >= 5:
                for f in range(max(0, b_kf - 1), min(8, b_kf + 2)):
                    file_mask = FILE_MASKS[f]
                    b_on_file = bp & file_mask
                    if not b_on_file:
                        black_mg -= self.SHIELD_MISSING
                        if not (wp & file_mask):
                            black_mg -= self.FILE_OPEN_NEAR_KING
                    else:
                        if not (b_on_file & self.RANK_7_MASK):
                            black_mg -= self.SHIELD_MOVED
                            if b_on_file & self.RANK_6_MASK:
                                black_mg += 5

        # Connected rooks (more than one rook)
        w_rooks_bb = rooks & occ_w
        b_rooks_bb = rooks & occ_b
        if w_rooks_bb & (w_rooks_bb - 1):
            white_mg += self.CONNECTED_ROOKS_MG
            white_eg += self.CONNECTED_ROOKS_EG
        if b_rooks_bb & (b_rooks_bb - 1):
            black_mg += self.CONNECTED_ROOKS_MG
            black_eg += self.CONNECTED_ROOKS_EG

        # Bishop pair
        w_bishops_bb = bishops & occ_w
        b_bishops_bb = bishops & occ_b
        if w_bishops_bb & (w_bishops_bb - 1):
            white_mg += self.bishop_pair_mg
            white_eg += self.bishop_pair_eg
        if b_bishops_bb & (b_bishops_bb - 1):
            black_mg += self.bishop_pair_mg
            black_eg += self.bishop_pair_eg

        # Cached pawn structure (doubled / isolated / backward / passed)
        p_w_mg, p_w_eg, p_b_mg, p_b_eg = self._pawn_terms(wp, bp)
        white_mg += p_w_mg
        white_eg += p_w_eg
        black_mg += p_b_mg
        black_eg += p_b_eg

        mg_score = white_mg - black_mg
        eg_score = white_eg - black_eg

        # [UPGRADE] Convert to the side-to-move's perspective BEFORE the floor
        # division. Previously "floor(x/256)" was negated for Black, which made
        # an otherwise identical position score 1 cp differently depending on
        # colour (asymmetric rounding). Now evaluate(P) == evaluate(mirror(P)).
        blended = mg_score * phase + eg_score * (256 - phase)
        if board.turn != chess.WHITE:
            blended = -blended
        return blended // 256
