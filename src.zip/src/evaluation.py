import chess

DEFAULT_WEIGHTS = {
    "mg_material": {
        str(chess.PAWN): 82, str(chess.KNIGHT): 337, str(chess.BISHOP): 365, 
        str(chess.ROOK): 477, str(chess.QUEEN): 1025, str(chess.KING): 0
    },
    "eg_material": {
        str(chess.PAWN): 94, str(chess.KNIGHT): 281, str(chess.BISHOP): 297, 
        str(chess.ROOK): 512, str(chess.QUEEN): 936, str(chess.KING): 0
    },
    "mg_bonuses": { "bishop_pair": 45 },
    "eg_bonuses": { "bishop_pair": 65 }
}

def _flip(table):
    flipped = []
    for r in reversed(range(8)):
        flipped.extend(table[r*8:(r+1)*8])
    return flipped

class Evaluator:
    MG_VALUES = { chess.PAWN: 82, chess.KNIGHT: 337, chess.BISHOP: 365, chess.ROOK: 477, chess.QUEEN: 1025, chess.KING: 0 }
    EG_VALUES = { chess.PAWN: 94, chess.KNIGHT: 281, chess.BISHOP: 297, chess.ROOK: 512, chess.QUEEN: 936, chess.KING: 0 }

    ATTACK_WEIGHTS = { chess.PAWN: 0, chess.KNIGHT: 2, chess.BISHOP: 2, chess.ROOK: 3, chess.QUEEN: 5, chess.KING: 0 }
    
    # Advanced Mobility Tables (Indexed by number of safe legal attacks)
    MOBILITY_BONUS = {
        chess.KNIGHT:  ([-30, -10,  0,  5, 10, 15, 20, 25, 30], [-30, -10,  0,  5, 10, 15, 20, 25, 30]),
        chess.BISHOP:  ([-25, -11,  0,  7, 14, 21, 28, 35, 42, 49, 56, 63, 70, 77], [-25, -11,  0,  7, 14, 21, 28, 35, 42, 49, 56, 63, 70, 77]),
        chess.ROOK:    ([-20, -10,  0,  4,  8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48], [-20, -10,  0,  4,  8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48]),
        chess.QUEEN:   ([-10,  -5,  0,  2,  4,  6,  8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50], [-10,  -5,  0,  2,  4,  6,  8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50])
    }

    # Positional Tables
    MG_PAWN_RAW = [
          0,   0,   0,   0,   0,   0,   0,   0,
         98, 134,  61,  95,  68, 126,  34, -11,
        -6,    7,  26,  31,  65,  56,  25, -20,
        -14,  13,   6,  21,  23,  12,  17, -23,
        -27,  -2,  -5,  12,  17,   6,  10, -25,
        -26,  -4,  -4, -10,   3,   3,  33, -12,
        -35,  -1, -20, -23, -15,  24,  38, -22,
          0,   0,   0,   0,   0,   0,   0,   0
    ]
    MG_KNIGHT_RAW = [
       -167, -89, -34, -49,  61, -97, -15, -107,
        -73, -41,  72,  36,  23,  62,   7,  -17,
        -47,  60,  37,  65,  84, 129,  73,   44,
         -9,  17,  19,  53,  37,  69,  18,   22,
        -13,   4,  16,  13,  28,  19,  21,   -8,
        -23,  -9,  12,  10,  19,  17,  25,  -16,
        -29, -53, -12,  -3,  -1,  18, -14, -19,
       -105, -21, -58, -33, -17, -28, -19,  -23
    ]
    MG_BISHOP_RAW = [
        -29,   4, -82, -37, -25, -42,   7,  -8,
        -26,  16, -18, -13,  30,  59,  18, -47,
        -16,  37,  43,  40,  35,  50,  37,  -2,
         -4,   5,  19,  50,  37,  37,   7,  -2,
         -6,  13,  13,  26,  34,  12,  10,   4,
          0,  15,  15,  15,  14,  27,  18,  10,
          4,  15,  16,   0,   7,  21,  33,   1,
        -33,  -3, -14, -21, -13, -12, -39, -21
    ]
    MG_ROOK_RAW = [
         32,  42,  32,  51,  63,  9,  31,  43,
         27,  32,  58,  62,  80, 67,  26,  44,
         -5,  19,  26,  36,  17, 45,  61,  16,
        -24, -11,   7,  26,  24, 35,  -8, -20,
        -36, -26, -12,  -1,   9, -7,   6, -23,
        -45, -25, -16, -17,   3,  0,  -5, -33,
        -44, -16, -20,  -9,  -1, 11,  -6, -71,
        -19, -13,   1,  17,  16,  7, -37, -26
    ]
    MG_QUEEN_RAW = [
        -28,   0,  29,  12,  59,  44,  43,  45,
        -24, -39,  -5,   1, -16,  57,  28,  54,
        -13, -17,   7,   8,  29,  56,  47,  57,
        -27, -27, -16, -16,  -1,  17,  -2,   1,
         -9, -26,  -9, -10,  -2,  -4,   3,  -3,
        -14,   2, -11,  -2,  -5,   2,  14,   5,
        -35,  -8,  11,   2,   8,  15,  -3,   1,
         -1, -18,  -9,  10, -15, -25, -31, -50
    ]
    MG_KING_RAW = [
        -65,  23,  16, -15, -56, -34,   2,  13,
         29,  -1, -20,  -7,  -8,  -4, -38, -29,
         -9,  24,   2, -16, -20,   6,  22, -22,
        -17, -20, -12, -27, -30, -25, -14, -36,
        -49,  -1, -27, -39, -46, -44, -33, -51,
        -14, -14, -22, -46, -44, -30, -15, -27,
          1,   7,  -8, -64, -43, -16,   9,   8,
        -15,  36,  12, -54,   8, -28,  24,  14
    ]

    EG_PAWN_RAW = [
          0,   0,   0,   0,   0,   0,   0,   0,
        178, 173, 158, 134, 147, 132, 165, 187,
         94, 100,  85,  67,  56,  53,  82,  84,
         32,  24,  13,   5,  -2,   4,  17,  17,
         13,   9,  -3,  -7,  -7,  -8,   3,  -1,
          4,   7,  -6,   1,   0,  -5,  -1,  -8,
         13,   8,   8,  10,  13,   0,   2,  -7,
          0,   0,   0,   0,   0,   0,   0,   0
    ]
    EG_KNIGHT_RAW = [
        -58, -38, -13, -28, -31, -27, -63, -99,
        -25,  -8, -25,  -2,  -9, -25, -24, -52,
        -24, -20,  10,   9,  -1,  -9, -19, -41,
        -17,   3,  22,  22,  22,  11,   8, -18,
        -18,  -6,  16,  25,  16,  17,   4, -18,
        -23,  -3,  -1,  15,  10,  -3, -20, -22,
        -42, -20, -10,  -5,  -2, -20, -23, -44,
        -29, -51, -23, -38, -29, -27, -43, -36
    ]
    EG_BISHOP_RAW = [
        -14, -21, -11,  -8,  -7,  -9, -17, -24,
         -8,  -4,   7, -12,  -3, -13,  -4, -14,
          2,  -8,   0,  -1,  -2,   6,   0,   4,
         -3,   9,  12,   9,  14,  10,   3,   2,
         -6,   3,  13,  19,   7,  10,  -3,  -9,
        -12,  -3,   8,  10,  13,   3,  -7, -15,
        -14, -18,  -7,  -1,   4,  -9, -15, -27,
        -23,  -9, -23,  -5,  -9, -16,  -5, -17
    ]
    EG_ROOK_RAW = [
         13,  10,  18,  15,  12,  12,   8,   5,
         11,  13,  13,  11,  -3,   3,   8,   3,
          7,   7,   7,   5,   4,  -3,  -5,  -3,
          4,   3,  13,   1,   2,   1,  -1,   2,
          3,   5,   8,   4,  -5,  -6,  -8, -11,
         -4,   0,  -5,  -1,  -7, -12,  -8, -16,
         -6,  -6,   0,   2,  -9,  -9, -11,  -3,
         -9,   2,   3,  -1,  -5, -13,   4, -20
    ]
    EG_QUEEN_RAW = [
         -9,  22,  22,  27,  27,  19,  10,  20,
        -17,  20,  32,  41,  58,  25,  30,   0,
        -20,   6,   9,  49,  47,  35,  19,   9,
          3,  22,  24,  45,  57,  40,  57,  36,
        -18,  28,  19,  47,  31,  34,  39,  23,
        -16, -27,  15,   6,   9,  17,  10,   5,
        -22, -23, -30, -16, -16, -23, -36, -32,
        -33, -28, -22, -43,  -5, -32, -20, -41
    ]
    EG_KING_RAW = [
        -74, -35, -18, -18, -11,  15,   4, -17,
        -12,  17,  14,  17,  17,  38,  23,  11,
         10,  17,  23,  15,  20,  45,  44,  13,
         -8,  22,  24,  27,  26,  33,  26,   3,
        -18,  -4,  21,  24,  27,  23,   9, -11,
        -19,  -3,  11,  21,  23,  16,   7,  -9,
        -27, -11,   4,  13,  14,   4,  -5, -17,
        -53, -34, -21, -11, -28, -14, -24, -43
    ]

    PST_MG = { chess.PAWN: _flip(MG_PAWN_RAW), chess.KNIGHT: _flip(MG_KNIGHT_RAW), chess.BISHOP: _flip(MG_BISHOP_RAW), chess.ROOK: _flip(MG_ROOK_RAW), chess.QUEEN: _flip(MG_QUEEN_RAW), chess.KING: _flip(MG_KING_RAW) }
    PST_EG = { chess.PAWN: _flip(EG_PAWN_RAW), chess.KNIGHT: _flip(EG_KNIGHT_RAW), chess.BISHOP: _flip(EG_BISHOP_RAW), chess.ROOK: _flip(EG_ROOK_RAW), chess.QUEEN: _flip(EG_QUEEN_RAW), chess.KING: _flip(EG_KING_RAW) }

    MG_PASSED_BONUS = [0, 10, 30, 52, 78, 115, 162, 0]
    EG_PASSED_BONUS = [0, 22, 55, 88, 142, 215, 290, 0]

    # [UPGRADE] King Pawn Shield Constants
    SHIELD_MISSING = 25
    SHIELD_MOVED = 10
    FILE_OPEN_NEAR_KING = 15
    
    # [UPGRADE 2.0] Connected Rooks Bonus
    CONNECTED_ROOKS_MG = 20
    CONNECTED_ROOKS_EG = 25
    
    # Rank Masks for PyPy bitwise speed
    RANK_2_MASK = 0x000000000000FF00
    RANK_3_MASK = 0x0000000000FF0000
    RANK_6_MASK = 0x0000FF0000000000
    RANK_7_MASK = 0x00FF000000000000

    FILE_MASKS = [chess.BB_FILES[i] for i in range(8)]
    ADJACENT_FILE_MASKS = []
    for i in range(8):
        mask = 0
        if i > 0: mask |= chess.BB_FILES[i-1]
        if i < 7: mask |= chess.BB_FILES[i+1]
        ADJACENT_FILE_MASKS.append(mask)

    WHITE_PASSED_MASKS = []
    BLACK_PASSED_MASKS = []
    KING_ZONE_MASKS = []

    for sq in range(64):
        file, rank = chess.square_file(sq), chess.square_rank(sq)
        w_mask = chess.BB_EMPTY
        for r in range(rank + 1, 8):
            for f in range(max(0, file - 1), min(8, file + 2)):
                w_mask |= chess.BB_SQUARES[chess.square(f, r)]
        WHITE_PASSED_MASKS.append(w_mask)
        
        b_mask = chess.BB_EMPTY
        for r in range(0, rank):
            for f in range(max(0, file - 1), min(8, file + 2)):
                b_mask |= chess.BB_SQUARES[chess.square(f, r)]
        BLACK_PASSED_MASKS.append(b_mask)

        kz_mask = chess.BB_SQUARES[sq]
        for f in range(max(0, file - 1), min(8, file + 2)):
            for r in range(max(0, rank - 1), min(8, rank + 2)):
                kz_mask |= chess.BB_SQUARES[chess.square(f, r)]
        KING_ZONE_MASKS.append(kz_mask)

    # King Safety Tables 
    KING_SAFETY_TABLE = [
          0,   0,   5,  10,  18,  28,  40,  55,  72,  92, 115, 141, 170, 202, 237, 275,
        316, 360, 407, 457, 510, 566, 625, 687, 752, 820, 891, 965, 1042, 1122, 1205, 1291
    ]

    def __init__(self, weights=None):
        self.weights = weights
        self.mg_values = self.MG_VALUES.copy()
        self.eg_values = self.EG_VALUES.copy()
        self.mg_bonuses = {}
        self.eg_bonuses = {}

        if weights:
            mg_vals = {int(k): v for k, v in weights.get("mg_material", {}).items()}
            eg_vals = {int(k): v for k, v in weights.get("eg_material", {}).items()}
            self.mg_values.update(mg_vals)
            self.eg_values.update(eg_vals)
            self.mg_bonuses = weights.get("mg_bonuses", {})
            self.eg_bonuses = weights.get("eg_bonuses", {})

    def evaluate(self, board: chess.Board) -> int:
        mg_values = self.mg_values
        eg_values = self.eg_values
        mg_bonuses = self.mg_bonuses
        eg_bonuses = self.eg_bonuses

        knights = len(board.pieces(chess.KNIGHT, chess.WHITE)) + len(board.pieces(chess.KNIGHT, chess.BLACK))
        bishops = len(board.pieces(chess.BISHOP, chess.WHITE)) + len(board.pieces(chess.BISHOP, chess.BLACK))
        rooks = len(board.pieces(chess.ROOK, chess.WHITE)) + len(board.pieces(chess.ROOK, chess.BLACK))
        queens = len(board.pieces(chess.QUEEN, chess.WHITE)) + len(board.pieces(chess.QUEEN, chess.BLACK))
        
        current_phase = min(24, knights * 1 + bishops * 1 + rooks * 2 + queens * 4)
        phase = (current_phase * 256) // 24
        
        white_mg, white_eg, black_mg, black_eg = 0, 0, 0, 0
        
        white_pawns = board.pieces(chess.PAWN, chess.WHITE)
        black_pawns = board.pieces(chess.PAWN, chess.BLACK)
        
        w_king_sq = board.king(chess.WHITE)
        b_king_sq = board.king(chess.BLACK)
        w_kz = self.KING_ZONE_MASKS[w_king_sq] if w_king_sq is not None else 0
        b_kz = self.KING_ZONE_MASKS[b_king_sq] if b_king_sq is not None else 0
        
        w_king_attack_weight = 0
        b_king_attack_weight = 0

        # Cache piece collections to optimize bitwise evaluations
        occupied_white = board.occupied_co[chess.WHITE]
        occupied_black = board.occupied_co[chess.BLACK]

        for square, piece in board.piece_map().items():
            ptype = piece.piece_type
            
            if piece.color == chess.WHITE:
                white_mg += mg_values[ptype] + self.PST_MG[ptype][square]
                white_eg += eg_values[ptype] + self.PST_EG[ptype][square]
            else:
                mirrored_sq = chess.square_mirror(square)
                black_mg += mg_values[ptype] + self.PST_MG[ptype][mirrored_sq]
                black_eg += eg_values[ptype] + self.PST_EG[ptype][mirrored_sq]

            # Mobility & Attack Multipliers
            if ptype != chess.PAWN and ptype != chess.KING:
                attacks = board.attacks(square)
                safe_attacks = attacks & ~board.occupied_co[piece.color]
                mobility_count = chess.popcount(int(safe_attacks))
                
                mob_table_mg, mob_table_eg = self.MOBILITY_BONUS[ptype]
                idx = min(mobility_count, len(mob_table_mg) - 1)
                
                if piece.color == chess.WHITE:
                    white_mg += mob_table_mg[idx]
                    white_eg += mob_table_eg[idx]
                    if attacks & b_kz:
                        b_king_attack_weight += self.ATTACK_WEIGHTS[ptype]
                else:
                    black_mg += mob_table_mg[idx]
                    black_eg += mob_table_eg[idx]
                    if attacks & w_kz:
                        w_king_attack_weight += self.ATTACK_WEIGHTS[ptype]

            # Rook Specific Structural Evaluations
            if ptype == chess.ROOK:
                f = chess.square_file(square)
                r = chess.square_rank(square)
                f_mask = self.FILE_MASKS[f]
                
                # Check for Open/Semi-Open files
                w_pawns_on_file = int(white_pawns) & f_mask
                b_pawns_on_file = int(black_pawns) & f_mask
                
                if piece.color == chess.WHITE:
                    if not w_pawns_on_file and not b_pawns_on_file:
                        white_mg += 25  # Open file
                        white_eg += 15
                    elif not w_pawns_on_file and b_pawns_on_file:
                        white_mg += 12  # Semi-open
                        white_eg += 8
                    if r == 6:  # 7th rank dominance
                        white_mg += 35
                        white_eg += 45
                else:
                    if not w_pawns_on_file and not b_pawns_on_file:
                        black_mg += 25
                        black_eg += 15
                    elif not b_pawns_on_file and w_pawns_on_file:
                        black_mg += 12
                        black_eg += 8
                    if r == 1:  # 2nd rank dominance (mirrored 7th)
                        black_mg += 35
                        black_eg += 45

        # Table-based Scaled Quadratic King Safety
        if w_king_attack_weight > 0:
            idx = min(w_king_attack_weight, len(self.KING_SAFETY_TABLE) - 1)
            white_mg -= self.KING_SAFETY_TABLE[idx]
        if b_king_attack_weight > 0:
            idx = min(b_king_attack_weight, len(self.KING_SAFETY_TABLE) - 1)
            black_mg -= self.KING_SAFETY_TABLE[idx]

        # [UPGRADE] King Pawn Shield Evaluation (MG only)
        if w_king_sq is not None:
            w_kf = chess.square_file(w_king_sq)
            if w_kf <= 2 or w_kf >= 5:
                for f in range(max(0, w_kf - 1), min(8, w_kf + 2)):
                    file_mask = self.FILE_MASKS[f]
                    w_pawns_on_file = int(white_pawns) & file_mask
                    
                    if not w_pawns_on_file:
                        white_mg -= self.SHIELD_MISSING
                        if not (int(black_pawns) & file_mask):
                            white_mg -= self.FILE_OPEN_NEAR_KING
                    else:
                        if not (w_pawns_on_file & self.RANK_2_MASK):
                            white_mg -= self.SHIELD_MOVED
                            if w_pawns_on_file & self.RANK_3_MASK:
                                white_mg += 5  

        if b_king_sq is not None:
            b_kf = chess.square_file(b_king_sq)
            if b_kf <= 2 or b_kf >= 5:
                for f in range(max(0, b_kf - 1), min(8, b_kf + 2)):
                    file_mask = self.FILE_MASKS[f]
                    b_pawns_on_file = int(black_pawns) & file_mask
                    
                    if not b_pawns_on_file:
                        black_mg -= self.SHIELD_MISSING
                        if not (int(white_pawns) & file_mask):
                            black_mg -= self.FILE_OPEN_NEAR_KING
                    else:
                        if not (b_pawns_on_file & self.RANK_7_MASK):
                            black_mg -= self.SHIELD_MOVED
                            if b_pawns_on_file & self.RANK_6_MASK:
                                black_mg += 5

        # [UPGRADE 2.0] Connected Rooks Optimization
        w_rooks_bb = int(board.pieces(chess.ROOK, chess.WHITE))
        b_rooks_bb = int(board.pieces(chess.ROOK, chess.BLACK))
        if w_rooks_bb & (w_rooks_bb - 1): # Rapid check for > 1 rook
            white_mg += self.CONNECTED_ROOKS_MG
            white_eg += self.CONNECTED_ROOKS_EG
        if b_rooks_bb & (b_rooks_bb - 1):
            black_mg += self.CONNECTED_ROOKS_MG
            black_eg += self.CONNECTED_ROOKS_EG

        # Bishop Pair Bonuses
        if len(board.pieces(chess.BISHOP, chess.WHITE)) >= 2:
            white_mg += mg_bonuses.get("bishop_pair", 45)
            white_eg += eg_bonuses.get("bishop_pair", 65)
        if len(board.pieces(chess.BISHOP, chess.BLACK)) >= 2:
            black_mg += mg_bonuses.get("bishop_pair", 45)
            black_eg += eg_bonuses.get("bishop_pair", 65)

        # Advanced Structure Logic
        for f in range(8):
            file_mask = self.FILE_MASKS[f]
            adj_mask = self.ADJACENT_FILE_MASKS[f]
            
            w_file = int(white_pawns) & file_mask
            b_file = int(black_pawns) & file_mask
            w_count = chess.popcount(w_file)
            b_count = chess.popcount(b_file)
            
            # Doubled Pawn evaluation
            if w_count > 1:
                white_mg -= 16 * (w_count - 1)
                white_eg -= 22 * (w_count - 1)
            if b_count > 1:
                black_mg -= 16 * (b_count - 1)
                black_eg -= 22 * (b_count - 1)
                
            # Isolated Pawn evaluation
            w_adj = int(white_pawns) & adj_mask
            b_adj = int(black_pawns) & adj_mask
            
            if w_count > 0 and chess.popcount(w_adj) == 0:
                white_mg -= 14 * w_count
                white_eg -= 14 * w_count
            if b_count > 0 and chess.popcount(b_adj) == 0:
                black_mg -= 14 * b_count
                black_eg -= 14 * b_count

            # Backward Pawn detection
            if w_count == 1:
                w_sq = chess.lsb(w_file)
                w_rank = chess.square_rank(w_sq)
                w_support_mask = adj_mask & w_adj
                is_backward = True
                for s in chess.SQUARES:
                    if w_support_mask & chess.BB_SQUARES[s]:
                        if chess.square_rank(s) < w_rank:
                            is_backward = False
                            break
                if is_backward and (chess.BB_SQUARES[chess.square(f, w_rank+1)] & int(black_pawns)):
                    white_mg -= 10
                    white_eg -= 12

            if b_count == 1:
                b_sq = chess.lsb(b_file)
                b_rank = chess.square_rank(b_sq)
                b_support_mask = adj_mask & b_adj
                is_backward = True
                for s in chess.SQUARES:
                    if b_support_mask & chess.BB_SQUARES[s]:
                        if chess.square_rank(s) > b_rank:
                            is_backward = False
                            break
                if is_backward and (chess.BB_SQUARES[chess.square(f, b_rank-1)] & int(white_pawns)):
                    black_mg -= 10
                    black_eg -= 12

        # Passed Pawn Evaluation
        for sq in chess.SQUARES:
            if int(white_pawns) & chess.BB_SQUARES[sq]:
                if not (int(black_pawns) & self.WHITE_PASSED_MASKS[sq]):
                    rank = chess.square_rank(sq)
                    white_mg += self.MG_PASSED_BONUS[rank]
                    white_eg += self.EG_PASSED_BONUS[rank]
            elif int(black_pawns) & chess.BB_SQUARES[sq]:
                if not (int(white_pawns) & self.BLACK_PASSED_MASKS[sq]):
                    rank = 7 - chess.square_rank(sq)
                    black_mg += self.MG_PASSED_BONUS[rank]
                    black_eg += self.EG_PASSED_BONUS[rank]

        mg_score = white_mg - black_mg
        eg_score = white_eg - black_eg
        
        score = (mg_score * phase + eg_score * (256 - phase)) // 256
        return score if board.turn == chess.WHITE else -score