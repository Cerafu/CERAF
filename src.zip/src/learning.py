import chess
import chess.pgn
import json
import logging
from datetime import datetime
from src.storage import DIRS

class GameTracker:
    def __init__(self):
        self.current_moves = []
        self.current_fen = None
        self.evaluations = []  # Tracks (move_index, score)
        self.game_active = False

    def start_new_game(self):
        if self.game_active:
            self.save_current_game()
        self.current_moves = []
        self.current_fen = None
        self.evaluations = []
        self.game_active = True

    def update_position(self, fen, moves):
        if len(moves) < len(self.current_moves):
            self.save_current_game()
            self.start_new_game()
        
        self.current_fen = fen
        self.current_moves = moves
        self.game_active = True

    def record_evaluation(self, move_index, score):
        self.evaluations.append((move_index, score))

    def save_current_game(self):
        if not self.game_active or not self.current_moves:
            return

        board = chess.Board()
        if self.current_fen:
            board.set_fen(self.current_fen)

        game = chess.pgn.Game()
        game.headers["Event"] = "CERAF Lichess Match"
        game.headers["Date"] = datetime.now().strftime("%Y.%m.%d")
        game.headers["White"] = "CERAF v2.0" if board.turn == chess.WHITE else "Opponent"
        game.headers["Black"] = "Opponent" if board.turn == chess.WHITE else "CERAF v2.0"
        
        node = game
        positions = []

        for move_str in self.current_moves:
            try:
                move = chess.Move.from_uci(move_str)
                if move in board.legal_moves:
                    positions.append((board.fen(), move_str))
                    board.push(move)
                    node = node.add_variation(move)
                else:
                    break
            except Exception:
                break

        result = board.result() if board.is_game_over() else "*"
        game.headers["Result"] = result

        pgn_path = DIRS["pgns"] / f"lichess_games_{datetime.now().strftime('%Y%m')}.pgn"
        with open(pgn_path, "a", encoding="utf-8") as f:
            f.write(str(game) + "\n\n")

        training_records = []
        eval_dict = {move_idx: score for move_idx, score in self.evaluations}
        
        for i, (fen, move_str) in enumerate(positions):
            score = eval_dict.get(i, 0)
            record = {
                "fen": fen,
                "move": move_str,
                "eval": score,
                "game_result": result,
                "timestamp": datetime.now().isoformat()
            }
            training_records.append(record)

        if training_records:
            training_path = DIRS["training"] / "lichess_training_data.jsonl"
            with open(training_path, "a") as f:
                for rec in training_records:
                    f.write(json.dumps(rec) + "\n")

        logging.info(f"Analyzed game. Saved {len(training_records)} training records.")
        
        self.current_moves = []
        self.current_fen = None
        self.evaluations = []
        self.game_active = False

tracker = GameTracker()