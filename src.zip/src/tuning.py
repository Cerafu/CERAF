import copy
import json
import logging
import math
from src.storage import load_model, save_model, DIRS
from src.evaluation import DEFAULT_WEIGHTS, Evaluator
import chess

def sigmoid(score):
    try:
        return 1 / (1 + math.exp(-score / 400.0))
    except OverflowError:
        return 0.0 if score < 0 else 1.0

def calculate_dataset_mse(weights, dataset):
    total_error = 0.0
    count = 0
    
    temp_evaluator = Evaluator(weights=weights)
    
    for record in dataset:
        result_str = record.get("game_result", "*")
        
        if result_str == "*":
            continue
            
        fen = record.get("fen")
        if result_str == "1-0":
            actual = 1.0
        elif result_str == "0-1":
            actual = 0.0
        else:
            actual = 0.5
            
        board = chess.Board(fen)
        score = temp_evaluator.evaluate(board)
        
        if board.turn == chess.BLACK:
            score = -score
        
        prediction = sigmoid(score)
        total_error += (prediction - actual) ** 2
        count += 1
        
    if count == 0:
        return float('inf')
    return total_error / count

def run_tuning():
    print("Initializing Texel Parameter Tuning...")
    logging.info("Starting Texel tuning session...")
    
    training_path = DIRS["training"] / "lichess_training_data.jsonl"
    if not training_path.exists():
        print("No training data found at D:\\Chess\\Training\\lichess_training_data.jsonl")
        print("Play games on Lichess or run self-play first to generate data!")
        return
        
    dataset = []
    with open(training_path, "r") as f:
        for line in f:
            if line.strip():
                dataset.append(json.loads(line))
                
    if len(dataset) < 10:
        print(f"Dataset too small ({len(dataset)} positions). Collect at least 10 positions before tuning.")
        return
        
    print(f"Loaded {len(dataset)} training positions.")
    
    current_weights = load_model() or DEFAULT_WEIGHTS
    best_mse = calculate_dataset_mse(current_weights, dataset)
    print(f"Current Model Baseline MSE: {best_mse:.6f}")
    
    temp_weights = copy.deepcopy(current_weights)
    converged = False
    
    while not converged:
        improved = False
        
        for category in temp_weights.keys():
            for param_str in list(temp_weights[category].keys()):
                if param_str == str(chess.KING) or param_str == str(chess.PAWN): 
                    continue
                    
                for adjustment in [-10, 10]:
                    candidate_weights = copy.deepcopy(temp_weights)
                    candidate_weights[category][param_str] += adjustment
                    
                    candidate_mse = calculate_dataset_mse(candidate_weights, dataset)
                    
                    if candidate_mse < best_mse:
                        best_mse = candidate_mse
                        temp_weights = candidate_weights
                        improved = True
                        print(f"  Improved! Param {param_str} ({category}) adjusted by {adjustment:+} | New MSE: {best_mse:.6f}")
        
        if improved:
            print("Saving intermediate improved model...")
            save_model(temp_weights, version_name="latest")
        else:
            converged = True
            
    print("Optimization complete! Reached local minimum.")
    logging.info(f"Texel Tuning updated weights. Final MSE: {best_mse:.6f}")