import sys
import threading
import time
import chess
import chess.syzygy
import logging
import multiprocessing
from src.search import Search
from src.learning import tracker
from src.opening_book import get_book_move

TABLEBASES = None
SEARCH_ID = 0  
PONDER_ENABLED = True

try:
    DEFAULT_THREADS = max(1, multiprocessing.cpu_count())
except Exception:
    DEFAULT_THREADS = 1

def parse_go_args(tokens):
    params = {}
    i = 0
    while i < len(tokens):
        key = tokens[i]
        if key in ["wtime", "btime", "winc", "binc", "movestogo", "movetime", "depth", "nodes"]:
            if i + 1 < len(tokens):
                try:
                    params[key] = int(tokens[i+1])
                except ValueError:
                    pass
                i += 2
            else:
                break
        elif key in ["infinite", "mate"]:
            params[key] = True
            i += 1
        else:
            i += 1
    return params

def calculate_time_limit(board, params):
    time_limit = 999999.0  
    depth_limit = 100
    node_limit = None

    if "infinite" in params:
        return time_limit, depth_limit, node_limit

    if "depth" in params:
        depth_limit = params["depth"]
    
    if "nodes" in params:
        node_limit = params["nodes"]

    if "movetime" in params:
        return params["movetime"] / 1000.0, depth_limit, node_limit

    is_white = board.turn == chess.WHITE
    remaining_ms = params.get("wtime") if is_white else params.get("btime")
    inc_ms = params.get("winc", 0) if is_white else params.get("binc", 0)
    movestogo = params.get("movestogo")

    if remaining_ms is not None:
        remaining_sec = remaining_ms / 1000.0
        inc_sec = inc_ms / 1000.0

        if movestogo and movestogo > 0:
            base = remaining_sec / movestogo
        else:
            phase = min(24, chess.popcount(board.occupied))
            factor = 28.0 if phase > 12 else 40.0  
            base = remaining_sec / factor

        allocated = base + (inc_sec * 0.75) 
        allocated = min(allocated, remaining_sec * 0.22)  
        allocated = max(0.04, allocated) 

        if allocated >= remaining_sec:
            allocated = max(0.001, remaining_sec - 0.1)
            
        time_limit = allocated
    elif "depth" not in params and "nodes" not in params:
        time_limit = 1.0

    return time_limit, depth_limit, node_limit

def uci_loop():
    global TABLEBASES
    global SEARCH_ID
    global PONDER_ENABLED
    
    board = chess.Board()
    search = Search()
    search.threads = DEFAULT_THREADS
    search_thread = None
    logging.info("UCI Loop Started")

    while True:
        try:
            line = sys.stdin.readline().strip()
            if not line:
                continue
            
            tokens = line.split()
            command = tokens[0]

            if command == "uci":
                print("id name CERAF Learning Ultra v2.0 SMP", flush=True)
                print("id author Cerafin C F", flush=True)
                print(f"option name Threads type spin default {DEFAULT_THREADS} min 1 max 128", flush=True)
                print("option name SyzygyPath type string default <empty>", flush=True)
                print("option name SyzygyProbeDepth type spin default 1 min 1 max 100", flush=True)
                print("option name SyzygyProbeLimit type spin default 5 min 0 max 6", flush=True)
                print("option name Ponder type check default true", flush=True)
                print("uciok", flush=True)
                
            elif command == "isready":
                print("readyok", flush=True)
                
            elif command == "setoption":
                name_idx = tokens.index("name") if "name" in tokens else -1
                value_idx = tokens.index("value") if "value" in tokens else -1
                if name_idx != -1 and value_idx != -1:
                    opt_name = " ".join(tokens[name_idx+1:value_idx]).lower()
                    opt_val = " ".join(tokens[value_idx+1:]).lower()
                    if opt_name == "threads":
                        try:
                            search.threads = max(1, int(opt_val))
                            logging.info(f"Threads set to {search.threads}")
                        except ValueError:
                            pass
                    elif opt_name == "syzygypath":
                        try:
                            TABLEBASES = chess.syzygy.open_tablebase(opt_val)
                            search.tablebase = TABLEBASES
                            logging.info(f"Loaded Syzygy tablebases successfully from {opt_val}")
                        except Exception as e:
                            logging.error(f"Error loading Syzygy tablebases: {e}")
                    elif opt_name == "syzygyprobedepth":
                        try:
                            search.syzygy_probe_depth = int(opt_val)
                        except ValueError:
                            pass
                    elif opt_name == "syzygyprobelimit":
                        try:
                            search.syzygy_probe_limit = int(opt_val)
                        except ValueError:
                            pass
                    elif opt_name == "ponder":
                        PONDER_ENABLED = (opt_val == "true")
                        logging.info(f"Ponder enabled set to {PONDER_ENABLED}")
                            
            elif command == "ucinewgame":
                if search_thread and search_thread.is_alive():
                    search.abort = True
                    search.timeout = True
                    SEARCH_ID += 1 
                    search_thread.join()
                tracker.start_new_game()
                board.reset()
                search.history_table = [[[0] * 64 for _ in range(64)] for _ in range(2)]
                search.killer_moves = [[None, None, None] for _ in range(128)]
                
            elif command == "position":
                if search_thread and search_thread.is_alive():
                    if getattr(search, 'is_pondering', False):
                        logging.info("Ponder miss or interrupted by new position.")
                    search.abort = True
                    search.timeout = True
                    SEARCH_ID += 1
                    search_thread.join()
                    
                fen = None
                moves = []
                
                try:
                    if len(tokens) >= 2 and tokens[1] == "startpos":
                        board.reset()
                        if "moves" in tokens:
                            moves_start = tokens.index("moves")
                            moves = tokens[moves_start+1:]
                    elif len(tokens) >= 2 and tokens[1] == "fen":
                        if "moves" in tokens:
                            moves_start = tokens.index("moves")
                            fen = " ".join(tokens[2:moves_start])
                            moves = tokens[moves_start+1:]
                        else:
                            fen = " ".join(tokens[2:])
                        board.set_fen(fen)
                    else:
                        continue

                    for move in moves:
                        board.push(chess.Move.from_uci(move))
                    tracker.update_position(fen, moves)
                except Exception as e:
                    logging.error(f"Error parsing position: {e}")
                    continue

            elif command == "go":
                if search_thread and search_thread.is_alive():
                    search.abort = True
                    search.timeout = True
                    SEARCH_ID += 1
                    search_thread.join()

                is_ponder = "ponder" in tokens
                if is_ponder and not PONDER_ENABLED:
                    is_ponder = False

                params = parse_go_args(tokens[1:])
                best_move = get_book_move(board)
                if best_move:
                    tracker.record_evaluation(len(board.move_stack), 0)
                    ponder_uci = ""
                    if PONDER_ENABLED:
                        board.push(best_move)
                        ponder_move = get_book_move(board)
                        if not ponder_move:
                            legal_fallbacks = list(board.legal_moves)
                            if legal_fallbacks:
                                ponder_move = legal_fallbacks[0]
                        if ponder_move:
                            ponder_uci = f" ponder {ponder_move.uci()}"
                        board.pop()
                    print(f"bestmove {best_move.uci()}{ponder_uci}", flush=True)
                    continue
                
                root_legal_moves = list(board.legal_moves)
                if not root_legal_moves:
                    print("bestmove 0000", flush=True)
                    continue
                    
                valid_ucis = {m.uci() for m in root_legal_moves}
                fallback_uci = root_legal_moves[0].uci()
                root_move_stack_len = len(board.move_stack)
                
                t_lim, d_lim, n_lim = calculate_time_limit(board, params)
                SEARCH_ID += 1
                current_search_id = SEARCH_ID
                
                search.abort = False
                search.timeout = False

                def search_worker(search_board, time_lim, depth_lim, node_lim, s_id, valid_moves, fallback, stack_len, pondering):
                    search.is_pondering = pondering
                    if pondering:
                        logging.info("Pondering started.")

                    try:
                        best, ponder, score = search.iterative_deepening(
                            search_board, 
                            time_limit=time_lim, 
                            depth_limit=depth_lim, 
                            node_limit=node_lim
                        )

                        if search.is_pondering and not search.abort:
                            logging.info("Ponder search finished by limits, waiting for ponderhit or stop.")
                            while search.is_pondering and not search.abort:
                                time.sleep(0.01)

                        if s_id == SEARCH_ID:
                            best_uci = best.uci() if best else fallback
                            if best_uci not in valid_moves:
                                logging.error(f"CRITICAL: Search output illegal move {best_uci}. Triggering fallback.")
                                best_uci = fallback
                            tracker.record_evaluation(stack_len, score)
                            
                            if ponder and PONDER_ENABLED:
                                print(f"bestmove {best_uci} ponder {ponder.uci()}", flush=True)
                                logging.info(f"bestmove printed with ponder move: {best_uci} ponder {ponder.uci()}")
                            else:
                                print(f"bestmove {best_uci}", flush=True)
                                logging.info(f"bestmove printed without ponder move: {best_uci}")
                        else:
                            logging.info("Stale search ignored due to SEARCH_ID mismatch.")
                    except Exception as e:
                        logging.error(f"Search error in thread: {str(e)}")
                        if s_id == SEARCH_ID:
                            print(f"bestmove {fallback}", flush=True)

                search_board = board.copy()
                search_thread = threading.Thread(
                    target=search_worker, 
                    args=(search_board, t_lim, d_lim, n_lim, current_search_id, valid_ucis, fallback_uci, root_move_stack_len, is_ponder)
                )
                search_thread.start()

            elif command == "ponderhit":
                if search_thread and search_thread.is_alive():
                    logging.info("ponderhit received, switching to normal time management.")
                    search.ponder_hit()

            elif command == "stop":
                if getattr(search, 'is_pondering', False):
                    logging.info("Pondering stopped via stop command.")
                search.abort = True
                search.timeout = True
                if search_thread and search_thread.is_alive():
                    search_thread.join()

            elif command == "quit":
                search.abort = True
                search.timeout = True
                if search_thread and search_thread.is_alive():
                    search_thread.join()
                tracker.save_current_game()
                break
                
        except Exception as e:
            logging.error(f"Engine error: {str(e)}")
            continue

if __name__ == "__main__":
    uci_loop()