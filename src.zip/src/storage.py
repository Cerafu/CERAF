import os
import json
import logging
from pathlib import Path
from datetime import datetime

BASE_DIR = Path(r"D:\Chess")
DIRS = {
    "books": BASE_DIR / "Books",
    "syzygy": BASE_DIR / "Syzygy",
    "pgns": BASE_DIR / "PGNs",
    "selfplay": BASE_DIR / "SelfPlay",
    "training": BASE_DIR / "Training",
    "models": BASE_DIR / "Models",
    "logs": BASE_DIR / "Logs",
    "benchmarks": BASE_DIR / "Benchmarks",
    "backups": BASE_DIR / "Backups",
}

def setup_directories():
    for name, path in DIRS.items():
        path.mkdir(parents=True, exist_ok=True)
    setup_logging()

def setup_logging():
    log_file = DIRS["logs"] / f"ceraf_engine_{datetime.now().strftime('%Y%m%d')}.log"
    logging.basicConfig(filename=log_file, level=logging.INFO, 
                        format='%(asctime)s - %(levelname)s - %(message)s')

def load_model():
    model_path = DIRS["models"] / "latest_model.json"
    if model_path.exists():
        with open(model_path, 'r') as f:
            return json.load(f)
    return None

def save_model(weights, version_name="latest"):
    model_path = DIRS["models"] / f"{version_name}_model.json"
    
    if version_name == "latest" and model_path.exists():
        backup_path = DIRS["backups"] / f"model_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        model_path.rename(backup_path)

    with open(model_path, 'w') as f:
        json.dump(weights, f, indent=4)
    logging.info(f"Model saved to {model_path}")

def save_training_data(data_records):
    filename = DIRS["training"] / f"data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jsonl"
    with open(filename, 'w') as f:
        for record in data_records:
            f.write(json.dumps(record) + '\n')