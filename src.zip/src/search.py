import chess
import chess.polyglot
import chess.syzygy
import time
import math
import logging
import threading
from src.evaluation import Evaluator
from src.tt import TranspositionTable
from src.storage import DIRS

PIECE_VALUES = (0, 100, 320, 330, 500, 950, 20000)

class Search:
    def __init__(self):
        self.evaluator = Evaluator()
        self.threads = 1
        self.nodes = [0] * 128
        self.start_time = 0
        self.time_limit = 1.0
        self.node_limit = None
        self.timeout = False
        self.abort = False
        self.is_pondering = False
        
        self.syzygy_probe_depth = 1
        self.syzygy_probe_limit = 5
        
        self.killer_moves = [[None, None, None] for _ in range(128)]
        self.history_table = [[[0] * 64 for _ in range(64)] for _ in range(2)]
        self.counter_moves = [[None] * 64 for _ in range(64)]
        
        self.tt = TranspositionTable(size_mb=64)
        
        self.tablebase = None
        try:
            self.tablebase = chess.syzygy.open_tablebase(str(DIRS["syzygy"]))
        except Exception:
            pass
            
        self.lmr_table = [[0] * 64 for _ in range(64)]
        for d in range(64):
            for m in range(64):
                if d >= 3 and m >= 3:
                    self.lmr_table[d][m] = int(0.4 + (math.log(d) * math.log(m)) / 2.0)
                    
        self.see_gain = [[0] * 32 for _ in range(128)]

    def ponder_hit(self):
        self.is_pondering = False
        self.start_time = time.time()

    def get_best_tb_move(self, board: chess.Board):
        best_move = None
        best_score = -999999
        best_dtz = None
        
        for move in board.legal_moves:
            board.push(move)
            
            if board.is_checkmate():
                score = 20000 - 100
                v_dtz = 0
            elif board.is_stalemate() or board.is_insufficient_material() or board.is_repetition(2):
                score = 0
                v_dtz = 0
            else:
                try:
                    v_wdl = -self.tablebase.probe_wdl(board)
                    v_dtz = -self.tablebase.probe_dtz(board)
                    
                    if v_wdl > 0:
                        score = 20000 - 100 - v_dtz
                    elif v_wdl < 0:
                        score = -20000 + 100 - v_dtz 
                    else:
                        eval_score = self.evaluator.evaluate(board)
                        our_eval = -eval_score
                        score = max(-50, min(50, our_eval // 100))
                except Exception:
                    board.pop()
                    continue
                    
            board.pop()
            
            if score > best_score:
                best_score = score
                best_move = move
                best_dtz = v_dtz
                
        return best_move, best_score, best_dtz

    def generate_tb_pv(self, board: chess.Board, max_length: int = 20):
        pv = []
        for _ in range(max_length):
            if board.is_game_over() or chess.popcount(board.occupied) > self.syzygy_probe_limit or board.castling_rights:
                break
            
            move, _, _ = self.get_best_tb_move(board)
            if not move:
                break
            
            pv.append(move)
            board.push(move)
            
        for _ in range(len(pv)):
            board.pop()
            
        return pv

    def static_exchange_evaluation(self, thread_id: int, board: chess.Board, move: chess.Move) -> int:
        target = move.to_square
        piece_on_target = board.piece_type_at(target)
        
        gain = self.see_gain[thread_id]
        gain[0] = PIECE_VALUES[piece_on_target] if piece_on_target else 0
        if move.promotion:
            gain[0] += PIECE_VALUES[move.promotion] - 100
            
        attacker_pt = board.piece_type_at(move.from_square)
        if not attacker_pt: return 0
        attacker_val = PIECE_VALUES[attacker_pt]
        
        color = not board.turn
        occupied = board.occupied ^ (1 << move.from_square)
        depth = 0
        
        while True:
            depth += 1
            gain[depth] = attacker_val - gain[depth - 1]
            if max(-gain[depth-1], gain[depth]) < 0: 
                break 
                
            attackers = board.attackers_mask(color, target) & occupied
            if not attackers:
                break
                
            found = False
            for pt in range(1, 7):
                pt_attackers = attackers & board.pieces_mask(pt, color)
                if pt_attackers:
                    sq = (pt_attackers & -pt_attackers).bit_length() - 1
                    attacker_val = PIECE_VALUES[pt]
                    occupied ^= (1 << sq)
                    found = True
                    break
                    
            if not found:
                break
            color = not color
            
        while depth > 1:
            depth -= 1
            gain[depth - 1] = -max(-gain[depth - 1], gain[depth])
            
        return gain[0]

    def check_limits(self, thread_id: int) -> bool:
        if self.timeout or self.abort: return True
        if self.is_pondering: return False
        
        if self.nodes[thread_id] & 1023 == 0:
            if self.node_limit is not None:
                total_nodes = sum(self.nodes[:self.threads])
                if total_nodes >= self.node_limit:
                    self.timeout = True
                    return True
            if time.time() - self.start_time >= self.time_limit:
                self.timeout = True
                return True
        return False

    def order_moves(self, thread_id: int, board: chess.Board, ply: int, tt_move: chess.Move = None):
        color = int(board.turn)
        k1, k2, k3 = self.killer_moves[ply] if ply < 128 else (None, None, None)
        
        countermove = None
        if board.move_stack:
            prev_move = board.peek()
            countermove = self.counter_moves[prev_move.from_square][prev_move.to_square]

        def score_move(move):
            if move == tt_move: return 400000
            
            promo = move.promotion
            if promo: return 350000 + PIECE_VALUES[promo]
            
            if board.is_capture(move):
                see_score = self.static_exchange_evaluation(thread_id, board, move)
                return 300000 + see_score if see_score >= 0 else -50000 + see_score
                
            if move == k1: return 100000
            if move == k2: return 90000
            if move == k3: return 80000
            if move == countermove: return 85000
            
            return self.history_table[color][move.from_square][move.to_square]

        moves = list(board.legal_moves)
        moves.sort(key=score_move, reverse=True)
        return moves

    def quiescence_search(self, thread_id: int, board: chess.Board, alpha: int, beta: int, ply: int, depth_limit: int = 6) -> int:
        self.nodes[thread_id] += 1
        if self.check_limits(thread_id): return alpha

        if ply > 0 and (board.halfmove_clock >= 100 or board.is_repetition(2) or board.is_insufficient_material()):
            return 0

        hash_key = chess.polyglot.zobrist_hash(board)
        tt_score, tt_move = self.tt.probe(hash_key, 0, alpha, beta)
        if tt_score is not None:
            return tt_score

        in_check = board.is_check()
        original_alpha = alpha

        if not in_check:
            stand_pat = self.evaluator.evaluate(board)
            if stand_pat >= beta: 
                if not self.timeout:
                    self.tt.store(hash_key, 0, beta, TranspositionTable.BETA, None)
                return beta
            if stand_pat > alpha: 
                alpha = stand_pat
        else:
            stand_pat = -99999

        if depth_limit <= 0: return alpha

        if in_check:
            q_moves = list(board.legal_moves)
            if not q_moves:
                return -99999 + ply
        else:
            q_moves = list(board.generate_legal_captures())
        
        def score_q_move(move):
            if move.promotion: return 350000 + PIECE_VALUES[move.promotion]
            return 300000 + self.static_exchange_evaluation(thread_id, board, move)
            
        q_moves.sort(key=score_q_move, reverse=True)

        best_move = None
        for move in q_moves:
            is_checking = board.gives_check(move)
            
            if not in_check:
                target_pt = board.piece_type_at(move.to_square)
                captured_val = PIECE_VALUES[target_pt] if target_pt else 0
                if move.promotion:
                    captured_val += PIECE_VALUES[move.promotion]
                
                if not is_checking:
                    if stand_pat + captured_val + 200 < alpha:
                        continue

                see_score = self.static_exchange_evaluation(thread_id, board, move)
                if see_score < 0 and not is_checking:
                    continue 
                if not move.promotion and not is_checking:
                    if stand_pat + see_score + 150 < alpha:
                        continue 

            board.push(move)
            try:
                score = -self.quiescence_search(thread_id, board, -beta, -alpha, ply + 1, depth_limit - 1)
            finally:
                board.pop()

            if self.timeout: return alpha
            
            if score >= beta: 
                if not self.timeout:
                    self.tt.store(hash_key, 0, beta, TranspositionTable.BETA, move)
                return beta
                
            if score > alpha: 
                alpha = score
                best_move = move

        if not self.timeout:
            flag = TranspositionTable.EXACT if alpha > original_alpha else TranspositionTable.ALPHA
            self.tt.store(hash_key, 0, alpha, flag, best_move)

        return alpha

    def alpha_beta(self, thread_id: int, board: chess.Board, depth: int, alpha: int, beta: int, ply: int, do_null: bool = True) -> int:
        self.nodes[thread_id] += 1
        if self.check_limits(thread_id): return alpha

        mate_value = 99999 - ply
        if alpha < -mate_value:
            alpha = -mate_value
        if beta > mate_value - 1:
            beta = mate_value - 1
        if alpha >= beta:
            return alpha

        if ply > 0 and (board.halfmove_clock >= 100 or board.is_repetition(2) or board.is_insufficient_material()):
            return 0

        hash_key = chess.polyglot.zobrist_hash(board)
        tt_score, tt_move = self.tt.probe(hash_key, depth, alpha, beta)
        if tt_score is not None:
            return tt_score

        if depth <= 0:
            return self.quiescence_search(thread_id, board, alpha, beta, ply)

        in_check = board.is_check()
        color = int(board.turn) 

        if in_check:
            depth += 1

        if self.tablebase is not None and not in_check and depth >= self.syzygy_probe_depth:
            if not board.castling_rights and board.halfmove_clock == 0 and chess.popcount(board.occupied) <= self.syzygy_probe_limit:
                try:
                    wdl = self.tablebase.probe_wdl(board)
                    tb_score = None
                    
                    if wdl == 2:
                        tb_score = 20000 - 100 - ply
                    elif wdl == -2:
                        tb_score = -20000 + 100 + ply
                    elif wdl in (0, 1, -1):
                        tb_score = 0
                    
                    if tb_score is not None:
                        if not self.timeout:
                            self.tt.store(hash_key, depth, tb_score, TranspositionTable.EXACT, None)
                        return tb_score
                except Exception:
                    pass

        static_eval = self.evaluator.evaluate(board)

        if not in_check and depth <= 3 and abs(beta) < 90000:
            margin = depth * 115
            if static_eval - margin >= beta:
                return static_eval - margin

        if not in_check and depth <= 3 and abs(alpha) < 90000:
            razor_margin = 300 + (depth * 100)
            if static_eval + razor_margin <= alpha:
                if depth <= 1:
                    return self.quiescence_search(thread_id, board, alpha, beta, ply)
                r_score = self.quiescence_search(thread_id, board, alpha, beta, ply)
                if r_score <= alpha:
                    return r_score

        if do_null and not in_check and depth >= 3:
            has_pieces = bool(board.occupied_co[color] & ~(board.pieces_mask(chess.PAWN, color) | board.pieces_mask(chess.KING, color)))
            if has_pieces:
                R = 3 + (depth // 6)
                board.push(chess.Move.null())
                try:
                    null_score = -self.alpha_beta(thread_id, board, depth - 1 - R, -beta, -beta + 1, ply + 1, do_null=False)
                finally:
                    board.pop()
                    
                if self.timeout: return alpha
                if null_score >= beta: return beta

        if depth >= 4 and tt_move is None and not in_check:
            self.alpha_beta(thread_id, board, depth - 2, alpha, beta, ply, do_null=False)
            _, tt_move = self.tt.probe(hash_key, 0, -100000, 100000)

        do_futility = False
        if not in_check and depth <= 2 and abs(alpha) < 90000:
            if static_eval + (depth * 250) <= alpha:
                do_futility = True

        moves = self.order_moves(thread_id, board, ply, tt_move)
        
        if not moves:
            return -99999 + ply if in_check else 0

        best_move = None
        original_alpha = alpha
        moves_searched = 0
        quiet_moves_searched = [] 

        for move in moves:
            is_capture_or_promotion = board.is_capture(move) or bool(move.promotion)
            gives_check = board.gives_check(move)
            is_tactical = is_capture_or_promotion or gives_check
            
            if not is_capture_or_promotion:
                quiet_moves_searched.append(move)
            
            if do_futility and not is_tactical:
                continue
            
            if not in_check and depth <= 3 and not is_tactical:
                move_count_limit = 4 + (depth * depth)
                if moves_searched >= move_count_limit:
                    continue
                    
                hist_val = self.history_table[color][move.from_square][move.to_square]
                if hist_val < -2000 * depth:
                    continue

            if not in_check and depth <= 4 and is_capture_or_promotion and not gives_check:
                if self.static_exchange_evaluation(thread_id, board, move) < -200 * depth:
                    continue

            board.push(move)
            try:
                new_depth = depth - 1
                
                if moves_searched == 0:
                    score = -self.alpha_beta(thread_id, board, new_depth, -beta, -alpha, ply + 1, do_null=True)
                else:
                    needs_full_search = True
                    if not in_check and moves_searched >= 3 and new_depth >= 3 and not is_tactical:
                        d_idx = min(new_depth, 63)
                        m_idx = min(moves_searched, 63)
                        reduction = self.lmr_table[d_idx][m_idx]
                        
                        hist_val = self.history_table[color][move.from_square][move.to_square]
                        if hist_val > 4000:
                            reduction -= 1
                        
                        reduction = max(1, min(reduction, new_depth - 1))
                        
                        score = -self.alpha_beta(thread_id, board, new_depth - reduction, -alpha - 1, -alpha, ply + 1, do_null=True)
                        if score <= alpha:
                            needs_full_search = False
                    
                    if needs_full_search:
                        score = -self.alpha_beta(thread_id, board, new_depth, -alpha - 1, -alpha, ply + 1, do_null=True)
                        if alpha < score < beta:
                            score = -self.alpha_beta(thread_id, board, new_depth, -beta, -alpha, ply + 1, do_null=True)
            finally:
                board.pop()
                
            moves_searched += 1
            if self.timeout: return alpha

            if score >= beta:
                if not self.timeout:
                    self.tt.store(hash_key, depth, beta, TranspositionTable.BETA, move)
                    
                bonus = depth * depth
                max_history = 16384
                
                if not is_capture_or_promotion:
                    if ply < 128 and move != self.killer_moves[ply][0]:
                        self.killer_moves[ply][2] = self.killer_moves[ply][1]
                        self.killer_moves[ply][1] = self.killer_moves[ply][0]
                        self.killer_moves[ply][0] = move
                        
                    hist_val = self.history_table[color][move.from_square][move.to_square]
                    self.history_table[color][move.from_square][move.to_square] += bonus - (hist_val * abs(bonus) // max_history)
                    
                    if board.move_stack:
                        prev_move = board.peek()
                        self.counter_moves[prev_move.from_square][prev_move.to_square] = move

                for q_move in quiet_moves_searched:
                    if q_move != move:
                        q_hist_val = self.history_table[color][q_move.from_square][q_move.to_square]
                        self.history_table[color][q_move.from_square][q_move.to_square] -= bonus + (q_hist_val * abs(bonus) // max_history)
                        
                return beta

            if score > alpha:
                alpha = score
                best_move = move

        if not self.timeout:
            flag = TranspositionTable.EXACT if alpha > original_alpha else TranspositionTable.ALPHA
            self.tt.store(hash_key, depth, alpha, flag, best_move)

        return alpha

    def _search_worker(self, thread_id: int, board: chess.Board, depth_limit: int):
        depth = 1
        last_completed_best_move = None
        last_completed_best_score = 0
        aspiration_delta = 45

        legal_moves = list(board.legal_moves)
        if not legal_moves:
            return None, None, 0

        while depth <= depth_limit:
            if self.check_limits(thread_id): break
            
            hash_key = chess.polyglot.zobrist_hash(board)
            _, root_tt_move = self.tt.probe(hash_key, 0, -100000, 100000)
            
            if depth > 2:
                alpha = last_completed_best_score - aspiration_delta
                beta = last_completed_best_score + aspiration_delta
            else:
                alpha, beta = -100000, 100000

            while True:
                if self.check_limits(thread_id): break
                
                current_best = None
                best_score = -100000
                moves = self.order_moves(thread_id, board, ply=0, tt_move=root_tt_move)
                search_alpha = alpha
                
                for idx, move in enumerate(moves):
                    board.push(move)
                    try:
                        if idx == 0:
                            score = -self.alpha_beta(thread_id, board, depth - 1, -beta, -search_alpha, ply=1, do_null=True)
                        else:
                            score = -self.alpha_beta(thread_id, board, depth - 1, -search_alpha - 1, -search_alpha, ply=1, do_null=True)
                            if search_alpha < score < beta:
                                score = -self.alpha_beta(thread_id, board, depth - 1, -beta, -search_alpha, ply=1, do_null=True)
                    finally:
                        board.pop()
                    
                    if self.timeout or self.abort: break
                    
                    if score > best_score:
                        best_score = score
                        current_best = move
                    if score > search_alpha:
                        search_alpha = score

                if self.timeout or self.abort: break

                if best_score <= alpha:
                    beta = (alpha + beta) // 2
                    alpha = max(-100000, alpha - aspiration_delta)
                    aspiration_delta *= 2
                elif best_score >= beta:
                    alpha = (alpha + beta) // 2
                    beta = min(100000, beta + aspiration_delta)
                    aspiration_delta *= 2
                else:
                    last_completed_best_move = current_best if current_best else last_completed_best_move
                    last_completed_best_score = best_score
                    aspiration_delta = 45 
                    break

            if self.timeout or self.abort: break
            
            if thread_id == 0:
                time_elapsed_ms = max(1, int((time.time() - self.start_time) * 1000))
                total_nodes = sum(self.nodes[:self.threads])
                nps = int((total_nodes / max(1, time_elapsed_ms)) * 1000)
                pv_str = last_completed_best_move.uci() if last_completed_best_move else ""
                print(f"info depth {depth} score cp {last_completed_best_score} nodes {total_nodes} nps {nps} time {time_elapsed_ms} pv {pv_str}", flush=True)

            depth += 1
            
        if thread_id == 0:
            if not last_completed_best_move:
                last_completed_best_move = legal_moves[0] if legal_moves else None
                
            ponder_move = None
            if last_completed_best_move:
                board.push(last_completed_best_move)
                if not board.is_game_over():
                    hash_key = chess.polyglot.zobrist_hash(board)
                    _, tt_move = self.tt.probe(hash_key, 0, -100000, 100000)
                    if tt_move and tt_move in board.legal_moves:
                        ponder_move = tt_move
                    else:
                        legal_fallbacks = list(board.legal_moves)
                        if legal_fallbacks:
                            ponder_move = legal_fallbacks[0]
                board.pop()
                
            return last_completed_best_move, ponder_move, last_completed_best_score

    def iterative_deepening(self, board: chess.Board, time_limit: float = 1.0, depth_limit: int = 100, node_limit: int = None):
        self.start_time = time.time()
        self.time_limit = time_limit
        self.node_limit = node_limit
        self.timeout = self.abort
        
        # Isolate node tracking dynamically for scaling limits safely
        self.nodes = [0] * max(1, self.threads)
        
        self.tt.new_search()
        legal_moves = list(board.legal_moves)
        if not legal_moves: return None, None, 0
        if len(legal_moves) == 1: 
            return legal_moves[0], None, 0

        # --- SYZYGY ROOT PROBE ---
        if self.tablebase and not board.castling_rights and board.halfmove_clock == 0 and chess.popcount(board.occupied) <= self.syzygy_probe_limit:
            try:
                wdl = self.tablebase.probe_wdl(board)
                if wdl is not None:
                    tb_move, tb_score, tb_dtz = self.get_best_tb_move(board)
                    if tb_move:
                        pv = self.generate_tb_pv(board, max_length=30)
                        pv_str = " ".join(m.uci() for m in pv)
                        
                        time_elapsed_ms = max(1, int((time.time() - self.start_time) * 1000))
                        print(f"info depth 99 score cp {tb_score} nodes {sum(self.nodes[:self.threads])} nps 0 time {time_elapsed_ms} pv {pv_str}", flush=True)
                        
                        while self.is_pondering and not self.abort:
                            time.sleep(0.01)
                            
                        ponder_move = pv[1] if len(pv) > 1 else None
                        return tb_move, ponder_move, tb_score
            except Exception as e:
                logging.error(f"Root TB Probe error: {e}")

        # --- MULTITHREADED LAZY SMP DISPATCH ---
        helper_threads = []
        for t_id in range(1, self.threads):
            t_board = board.copy()
            t = threading.Thread(target=self._search_worker, args=(t_id, t_board, depth_limit))
            t.daemon = True
            helper_threads.append(t)
            t.start()
            
        best_move, ponder, score = self._search_worker(0, board, depth_limit)
        
        # Stop flag terminates the entire thread pool cleanly during abort logic
        self.abort = True 
        for t in helper_threads:
            t.join()
            
        return best_move, ponder, score