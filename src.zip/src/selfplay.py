import chess
import chess.pgn
import datetime
import json
from src.search import Search
from src.storage import DIRS

def run_selfplay(games=10, depth=3):
    print(f"Starting self-play loop for {games} games...")
    search_white = Search()
    search_black = Search()

    for i in range(games):
        board = chess.Board()
        game = chess.pgn.Game()
        game.headers["Event"] = "CERAF Self-Play Generation"
        game.headers["Date"] = datetime.datetime.now().strftime("%Y.%m.%d")
        game.headers["White"] = "CERAF_Current v2.0"
        game.headers["Black"] = "CERAF_Current v2.0"
        
        node = game
        positions = []
        
        while not board.is_game_over():
            if board.turn == chess.WHITE:
                move, _, score = search_white.iterative_deepening(board, time_limit=0.5) 
            else:
                move, _, score = search_black.iterative_deepening(board, time_limit=0.5)
            
            if not move:
                break
                
            positions.append((board.fen(), move.uci(), score))
            board.push(move)
            node = node.add_variation(move)
        
        result = board.result()
        game.headers["Result"] = result
        
        pgn_path = DIRS["selfplay"] / f"selfplay_batch_{datetime.datetime.now().strftime('%Y%m%d')}.pgn"
        with open(pgn_path, "a", encoding="utf-8") as f:
            f.write(str(game) + "\n\n")
            
        training_records = []
        for fen, move_str, score in positions:
            record = {
                "fen": fen,
                "move": move_str,
                "eval": score,
                "game_result": result,
                "timestamp": datetime.datetime.now().isoformat()
            }
            training_records.append(record)
            
        training_path = DIRS["training"] / "lichess_training_data.jsonl"
        with open(training_path, "a") as f:
            for rec in training_records:
                f.write(json.dumps(rec) + "\n")
                
        print(f"Game {i+1}/{games} completed. Result: {result} | Extracted {len(positions)} positions.")