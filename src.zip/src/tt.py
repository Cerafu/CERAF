class TranspositionTable:
    EXACT = 0
    ALPHA = 1  
    BETA = 2   

    def __init__(self, size_mb: int = 64):
        # Calculate capacity. In 64-bit Python/PyPy, a 6-item tuple + references is approx ~96 bytes.
        bytes_available = size_mb * 1024 * 1024
        target_entries = bytes_available // 96
        
        self.buckets = 1
        while self.buckets * 4 <= target_entries:
            self.buckets *= 2
            
        self.mask = self.buckets - 1
        self.capacity = self.buckets * 2
        
        # We pack entries as tuples to leverage Python's GIL for atomic, lock-free concurrency.
        # Tuple format: (zobrist_key, depth, score, flag, best_move, age)
        self.entries = [None] * self.capacity
        self.current_age = 0

    def new_search(self):
        self.current_age += 1

    def probe(self, zobrist_key: int, depth: int, alpha: int, beta: int):
        idx0 = (zobrist_key & self.mask) << 1
        idx1 = idx0 + 1

        entry = self.entries[idx0]
        if entry is not None and entry[0] == zobrist_key:
            best_move = entry[4]
            if entry[1] >= depth:
                flag = entry[3]
                score = entry[2]
                if flag == self.EXACT:
                    return score, best_move
                elif flag == self.ALPHA and score <= alpha:
                    return alpha, best_move
                elif flag == self.BETA and score >= beta:
                    return beta, best_move
            return None, best_move

        entry = self.entries[idx1]
        if entry is not None and entry[0] == zobrist_key:
            best_move = entry[4]
            if entry[1] >= depth:
                flag = entry[3]
                score = entry[2]
                if flag == self.EXACT:
                    return score, best_move
                elif flag == self.ALPHA and score <= alpha:
                    return alpha, best_move
                elif flag == self.BETA and score >= beta:
                    return beta, best_move
            return None, best_move
                
        return None, None

    def store(self, zobrist_key: int, depth: int, score: int, flag: int, best_move):
        idx0 = (zobrist_key & self.mask) << 1
        idx1 = idx0 + 1

        entry0 = self.entries[idx0]
        
        # Always replace if empty, from an old search age, or if the new depth is deeper
        if entry0 is None or entry0[5] < self.current_age or depth >= entry0[1]:
            self.entries[idx0] = (zobrist_key, depth, score, flag, best_move, self.current_age)
            return

        # Store in secondary slot to maintain depth-preferred TT architecture safely
        self.entries[idx1] = (zobrist_key, depth, score, flag, best_move, self.current_age)